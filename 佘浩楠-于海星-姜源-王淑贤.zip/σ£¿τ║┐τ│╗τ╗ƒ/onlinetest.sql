/*
Navicat MySQL Data Transfer

Source Server         : aaa
Source Server Version : 50621
Source Host           : localhost:3306
Source Database       : onlinetest

Target Server Type    : MYSQL
Target Server Version : 50621
File Encoding         : 65001

Date: 2018-08-06 13:06:09
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `dict`
-- ----------------------------
DROP TABLE IF EXISTS `dict`;
CREATE TABLE `dict` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` varchar(255) NOT NULL COMMENT '值',
  `content` varchar(255) NOT NULL COMMENT '值的相关解释',
  `code` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL COMMENT '类型',
  `version` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`,`type`),
  UNIQUE KEY `code_2` (`code`,`type`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of dict
-- ----------------------------
INSERT INTO `dict` VALUES ('1', '0', '用户状态_可用', 'available', 'userstatus', '0');
INSERT INTO `dict` VALUES ('2', '1', '用户状态_禁用', 'disable', 'userstatus', '0');
INSERT INTO `dict` VALUES ('3', '0', '用户类型_管理员', 'admin', 'usertype', '0');
INSERT INTO `dict` VALUES ('4', '2', '用户类型_学生', 'student', 'usertype', '0');
INSERT INTO `dict` VALUES ('5', '1', '用户类型_教师', 'teacher', 'usertype', '0');
INSERT INTO `dict` VALUES ('8', '0', '性别_男', 'men', 'sex', '0');
INSERT INTO `dict` VALUES ('9', '1', '性别_女', 'women', 'sex', '0');
INSERT INTO `dict` VALUES ('10', '0', '登陆结果_成功', 'success', 'login_result', '0');
INSERT INTO `dict` VALUES ('11', '1', '登陆结果_失败', 'fail', 'login_result', '0');
INSERT INTO `dict` VALUES ('12', '0', '试卷状态_开放', 'open', 'exam_status', '0');
INSERT INTO `dict` VALUES ('13', '1', '试卷状态_关闭', 'close', 'exam_status', '0');
INSERT INTO `dict` VALUES ('14', 'A', '选项_A', 'a', 'question_selected', '0');
INSERT INTO `dict` VALUES ('15', 'B', '选项_B', 'b', 'question_selected', '0');
INSERT INTO `dict` VALUES ('16', 'C', '选项_C', 'c', 'question_selected', '0');
INSERT INTO `dict` VALUES ('17', 'D', '选项_D', 'd', 'question_selected', '0');
INSERT INTO `dict` VALUES ('18', '0', '题型_选择题', 'select', 'question_type', '0');
INSERT INTO `dict` VALUES ('19', '1', '题型_判断题', 'judge', 'question_type', '0');
INSERT INTO `dict` VALUES ('20', '0', '判断_正确', 'T', 'question_judge', '0');
INSERT INTO `dict` VALUES ('21', '1', '判断_错误', 'F', 'question_judge', '0');
INSERT INTO `dict` VALUES ('22', '2', '试卷状态_无试题', 'noquestion', 'exam_status', '0');

-- ----------------------------
-- Table structure for `exam`
-- ----------------------------
DROP TABLE IF EXISTS `exam`;
CREATE TABLE `exam` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subjectId` int(11) NOT NULL COMMENT '科目ID',
  `examTime` int(11) NOT NULL COMMENT '考试时间',
  `examStatusId` int(11) NOT NULL COMMENT '试卷状态',
  `content` varchar(255) NOT NULL COMMENT '试题相关描述',
  `version` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `content` (`content`),
  KEY `sub_fk_1` (`subjectId`),
  KEY `status_fk_2` (`examStatusId`),
  CONSTRAINT `status_fk_2` FOREIGN KEY (`examStatusId`) REFERENCES `dict` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `sub_fk_1` FOREIGN KEY (`subjectId`) REFERENCES `subject` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of exam
-- ----------------------------
INSERT INTO `exam` VALUES ('1', '1', '60', '12', '操作系统卷一', '8');
INSERT INTO `exam` VALUES ('2', '1', '60', '12', '操作系统卷二', '7');
INSERT INTO `exam` VALUES ('3', '2', '60', '12', 'C语言卷一', '1');
INSERT INTO `exam` VALUES ('4', '2', '60', '12', 'C语言卷二', '1');
INSERT INTO `exam` VALUES ('5', '1', '11', '12', '操作系统卷三', '1');

-- ----------------------------
-- Table structure for `exam_question`
-- ----------------------------
DROP TABLE IF EXISTS `exam_question`;
CREATE TABLE `exam_question` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `examId` int(11) NOT NULL COMMENT '试题ID',
  `questId` int(11) NOT NULL COMMENT '问题ID',
  `version` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `exam_fk_1` (`examId`),
  KEY `ques_fk_2` (`questId`),
  CONSTRAINT `exam_fk_1` FOREIGN KEY (`examId`) REFERENCES `exam` (`id`),
  CONSTRAINT `ques_fk_2` FOREIGN KEY (`questId`) REFERENCES `questions` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=261 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of exam_question
-- ----------------------------
INSERT INTO `exam_question` VALUES ('141', '2', '24', '0');
INSERT INTO `exam_question` VALUES ('142', '2', '25', '0');
INSERT INTO `exam_question` VALUES ('143', '2', '26', '0');
INSERT INTO `exam_question` VALUES ('144', '2', '27', '0');
INSERT INTO `exam_question` VALUES ('145', '2', '28', '0');
INSERT INTO `exam_question` VALUES ('146', '2', '29', '0');
INSERT INTO `exam_question` VALUES ('147', '2', '30', '0');
INSERT INTO `exam_question` VALUES ('148', '2', '31', '0');
INSERT INTO `exam_question` VALUES ('149', '2', '32', '0');
INSERT INTO `exam_question` VALUES ('150', '2', '39', '0');
INSERT INTO `exam_question` VALUES ('151', '2', '49', '0');
INSERT INTO `exam_question` VALUES ('152', '2', '50', '0');
INSERT INTO `exam_question` VALUES ('153', '2', '51', '0');
INSERT INTO `exam_question` VALUES ('154', '2', '52', '0');
INSERT INTO `exam_question` VALUES ('155', '2', '53', '0');
INSERT INTO `exam_question` VALUES ('156', '2', '54', '0');
INSERT INTO `exam_question` VALUES ('157', '2', '55', '0');
INSERT INTO `exam_question` VALUES ('158', '2', '56', '0');
INSERT INTO `exam_question` VALUES ('159', '2', '57', '0');
INSERT INTO `exam_question` VALUES ('160', '2', '58', '0');
INSERT INTO `exam_question` VALUES ('161', '3', '64', '0');
INSERT INTO `exam_question` VALUES ('162', '3', '65', '0');
INSERT INTO `exam_question` VALUES ('163', '3', '66', '0');
INSERT INTO `exam_question` VALUES ('164', '3', '69', '0');
INSERT INTO `exam_question` VALUES ('165', '3', '70', '0');
INSERT INTO `exam_question` VALUES ('166', '3', '75', '0');
INSERT INTO `exam_question` VALUES ('167', '3', '77', '0');
INSERT INTO `exam_question` VALUES ('168', '3', '78', '0');
INSERT INTO `exam_question` VALUES ('169', '3', '80', '0');
INSERT INTO `exam_question` VALUES ('170', '3', '81', '0');
INSERT INTO `exam_question` VALUES ('171', '3', '71', '0');
INSERT INTO `exam_question` VALUES ('172', '3', '72', '0');
INSERT INTO `exam_question` VALUES ('173', '3', '73', '0');
INSERT INTO `exam_question` VALUES ('174', '3', '87', '0');
INSERT INTO `exam_question` VALUES ('175', '3', '88', '0');
INSERT INTO `exam_question` VALUES ('176', '3', '89', '0');
INSERT INTO `exam_question` VALUES ('177', '3', '90', '0');
INSERT INTO `exam_question` VALUES ('178', '3', '91', '0');
INSERT INTO `exam_question` VALUES ('179', '3', '92', '0');
INSERT INTO `exam_question` VALUES ('180', '3', '93', '0');
INSERT INTO `exam_question` VALUES ('181', '4', '71', '0');
INSERT INTO `exam_question` VALUES ('182', '4', '72', '0');
INSERT INTO `exam_question` VALUES ('183', '4', '73', '0');
INSERT INTO `exam_question` VALUES ('184', '4', '87', '0');
INSERT INTO `exam_question` VALUES ('185', '4', '88', '0');
INSERT INTO `exam_question` VALUES ('186', '4', '89', '0');
INSERT INTO `exam_question` VALUES ('187', '4', '90', '0');
INSERT INTO `exam_question` VALUES ('188', '4', '91', '0');
INSERT INTO `exam_question` VALUES ('189', '4', '93', '0');
INSERT INTO `exam_question` VALUES ('190', '4', '94', '0');
INSERT INTO `exam_question` VALUES ('191', '4', '64', '0');
INSERT INTO `exam_question` VALUES ('192', '4', '65', '0');
INSERT INTO `exam_question` VALUES ('193', '4', '66', '0');
INSERT INTO `exam_question` VALUES ('194', '4', '69', '0');
INSERT INTO `exam_question` VALUES ('195', '4', '70', '0');
INSERT INTO `exam_question` VALUES ('196', '4', '75', '0');
INSERT INTO `exam_question` VALUES ('197', '4', '77', '0');
INSERT INTO `exam_question` VALUES ('198', '4', '78', '0');
INSERT INTO `exam_question` VALUES ('199', '4', '79', '0');
INSERT INTO `exam_question` VALUES ('200', '4', '80', '0');
INSERT INTO `exam_question` VALUES ('221', '1', '24', '0');
INSERT INTO `exam_question` VALUES ('222', '1', '25', '0');
INSERT INTO `exam_question` VALUES ('223', '1', '26', '0');
INSERT INTO `exam_question` VALUES ('224', '1', '27', '0');
INSERT INTO `exam_question` VALUES ('225', '1', '28', '0');
INSERT INTO `exam_question` VALUES ('226', '1', '30', '0');
INSERT INTO `exam_question` VALUES ('227', '1', '32', '0');
INSERT INTO `exam_question` VALUES ('228', '1', '33', '0');
INSERT INTO `exam_question` VALUES ('229', '1', '34', '0');
INSERT INTO `exam_question` VALUES ('230', '1', '35', '0');
INSERT INTO `exam_question` VALUES ('231', '1', '44', '0');
INSERT INTO `exam_question` VALUES ('232', '1', '45', '0');
INSERT INTO `exam_question` VALUES ('233', '1', '46', '0');
INSERT INTO `exam_question` VALUES ('234', '1', '47', '0');
INSERT INTO `exam_question` VALUES ('235', '1', '48', '0');
INSERT INTO `exam_question` VALUES ('236', '1', '49', '0');
INSERT INTO `exam_question` VALUES ('237', '1', '51', '0');
INSERT INTO `exam_question` VALUES ('238', '1', '52', '0');
INSERT INTO `exam_question` VALUES ('239', '1', '53', '0');
INSERT INTO `exam_question` VALUES ('240', '1', '54', '0');
INSERT INTO `exam_question` VALUES ('241', '5', '24', '0');
INSERT INTO `exam_question` VALUES ('242', '5', '25', '0');
INSERT INTO `exam_question` VALUES ('243', '5', '26', '0');
INSERT INTO `exam_question` VALUES ('244', '5', '27', '0');
INSERT INTO `exam_question` VALUES ('245', '5', '28', '0');
INSERT INTO `exam_question` VALUES ('246', '5', '29', '0');
INSERT INTO `exam_question` VALUES ('247', '5', '30', '0');
INSERT INTO `exam_question` VALUES ('248', '5', '31', '0');
INSERT INTO `exam_question` VALUES ('249', '5', '32', '0');
INSERT INTO `exam_question` VALUES ('250', '5', '33', '0');
INSERT INTO `exam_question` VALUES ('251', '5', '55', '0');
INSERT INTO `exam_question` VALUES ('252', '5', '56', '0');
INSERT INTO `exam_question` VALUES ('253', '5', '57', '0');
INSERT INTO `exam_question` VALUES ('254', '5', '58', '0');
INSERT INTO `exam_question` VALUES ('255', '5', '59', '0');
INSERT INTO `exam_question` VALUES ('256', '5', '60', '0');
INSERT INTO `exam_question` VALUES ('257', '5', '61', '0');
INSERT INTO `exam_question` VALUES ('258', '5', '62', '0');
INSERT INTO `exam_question` VALUES ('259', '5', '63', '0');
INSERT INTO `exam_question` VALUES ('260', '5', '74', '0');

-- ----------------------------
-- Table structure for `loginmsg`
-- ----------------------------
DROP TABLE IF EXISTS `loginmsg`;
CREATE TABLE `loginmsg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userName` varchar(255) NOT NULL COMMENT '用户名',
  `userIp` varchar(255) NOT NULL COMMENT '登陆IP',
  `loginTime` datetime NOT NULL COMMENT '登陆时间',
  `loginStatusId` int(11) NOT NULL COMMENT '登陆状态',
  `version` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `user_fk_1` (`userName`),
  KEY `lStatus_fk_2` (`loginStatusId`),
  CONSTRAINT `lStatus_fk_2` FOREIGN KEY (`loginStatusId`) REFERENCES `dict` (`id`),
  CONSTRAINT `user_fk_1` FOREIGN KEY (`userName`) REFERENCES `user` (`userName`)
) ENGINE=InnoDB AUTO_INCREMENT=205 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of loginmsg
-- ----------------------------
INSERT INTO `loginmsg` VALUES ('11', '1000', '127.0.0.1', '2018-05-14 20:03:08', '10', '0');
INSERT INTO `loginmsg` VALUES ('12', '1000', '127.0.0.1', '2018-05-14 20:33:29', '11', '0');
INSERT INTO `loginmsg` VALUES ('13', '1000', '127.0.0.1', '2018-05-14 20:56:54', '11', '0');
INSERT INTO `loginmsg` VALUES ('14', '1000', '127.0.0.1', '2018-05-14 20:57:13', '11', '0');
INSERT INTO `loginmsg` VALUES ('15', '1000', '127.0.0.1', '2018-05-14 20:57:27', '10', '0');
INSERT INTO `loginmsg` VALUES ('16', '1000', '127.0.0.1', '2018-05-14 21:02:29', '10', '0');
INSERT INTO `loginmsg` VALUES ('17', '1000', '127.0.0.1', '2018-05-14 21:57:42', '10', '0');
INSERT INTO `loginmsg` VALUES ('18', '1000', '127.0.0.1', '2018-05-14 22:05:53', '10', '0');
INSERT INTO `loginmsg` VALUES ('19', '1000', '127.0.0.1', '2018-05-14 22:08:18', '10', '0');
INSERT INTO `loginmsg` VALUES ('20', '1000', '127.0.0.1', '2018-05-14 22:13:04', '10', '0');
INSERT INTO `loginmsg` VALUES ('21', '1000', '127.0.0.1', '2018-05-14 22:22:30', '10', '0');
INSERT INTO `loginmsg` VALUES ('22', '1000', '127.0.0.1', '2018-05-14 22:26:01', '10', '0');
INSERT INTO `loginmsg` VALUES ('23', '1000', '127.0.0.1', '2018-05-15 09:55:28', '10', '0');
INSERT INTO `loginmsg` VALUES ('24', '1000', '127.0.0.1', '2018-05-15 10:55:02', '10', '0');
INSERT INTO `loginmsg` VALUES ('25', '1000', '127.0.0.1', '2018-05-15 15:18:57', '10', '0');
INSERT INTO `loginmsg` VALUES ('26', '1000', '127.0.0.1', '2018-05-15 16:03:40', '10', '0');
INSERT INTO `loginmsg` VALUES ('27', '1000', '127.0.0.1', '2018-05-15 16:14:05', '10', '0');
INSERT INTO `loginmsg` VALUES ('28', '1000', '127.0.0.1', '2018-05-15 16:23:48', '10', '0');
INSERT INTO `loginmsg` VALUES ('29', '1000', '127.0.0.1', '2018-05-15 17:26:38', '10', '0');
INSERT INTO `loginmsg` VALUES ('30', '1000', '127.0.0.1', '2018-05-15 17:32:29', '10', '0');
INSERT INTO `loginmsg` VALUES ('31', '1000', '127.0.0.1', '2018-05-15 17:44:48', '10', '0');
INSERT INTO `loginmsg` VALUES ('32', '1000', '127.0.0.1', '2018-05-15 19:37:13', '10', '0');
INSERT INTO `loginmsg` VALUES ('33', '1000', '127.0.0.1', '2018-05-15 20:46:11', '10', '0');
INSERT INTO `loginmsg` VALUES ('34', '1000', '127.0.0.1', '2018-05-15 21:15:21', '10', '0');
INSERT INTO `loginmsg` VALUES ('35', '1000', '127.0.0.1', '2018-05-15 21:31:06', '10', '0');
INSERT INTO `loginmsg` VALUES ('36', '1000', '127.0.0.1', '2018-05-15 21:48:16', '10', '0');
INSERT INTO `loginmsg` VALUES ('37', '1000', '127.0.0.1', '2018-05-15 22:08:12', '10', '0');
INSERT INTO `loginmsg` VALUES ('38', '1000', '127.0.0.1', '2018-05-15 22:14:36', '11', '0');
INSERT INTO `loginmsg` VALUES ('39', '1000', '127.0.0.1', '2018-05-15 22:14:43', '10', '0');
INSERT INTO `loginmsg` VALUES ('40', '1000', '127.0.0.1', '2018-05-15 22:22:06', '10', '0');
INSERT INTO `loginmsg` VALUES ('41', '1000', '127.0.0.1', '2018-05-15 22:24:07', '11', '0');
INSERT INTO `loginmsg` VALUES ('42', '1000', '127.0.0.1', '2018-05-15 22:24:18', '10', '0');
INSERT INTO `loginmsg` VALUES ('43', '1000', '127.0.0.1', '2018-05-15 22:31:53', '11', '0');
INSERT INTO `loginmsg` VALUES ('44', '1000', '127.0.0.1', '2018-05-15 22:31:58', '10', '0');
INSERT INTO `loginmsg` VALUES ('45', '1000', '127.0.0.1', '2018-05-15 22:42:02', '10', '0');
INSERT INTO `loginmsg` VALUES ('46', '1000', '127.0.0.1', '2018-05-15 22:49:29', '10', '0');
INSERT INTO `loginmsg` VALUES ('47', '1000', '127.0.0.1', '2018-05-16 10:28:49', '11', '0');
INSERT INTO `loginmsg` VALUES ('48', '1000', '127.0.0.1', '2018-05-16 10:29:00', '10', '0');
INSERT INTO `loginmsg` VALUES ('49', '1000', '127.0.0.1', '2018-05-16 10:34:30', '10', '0');
INSERT INTO `loginmsg` VALUES ('50', '1000', '127.0.0.1', '2018-05-16 11:14:56', '10', '0');
INSERT INTO `loginmsg` VALUES ('51', '1000', '127.0.0.1', '2018-05-16 11:47:08', '10', '0');
INSERT INTO `loginmsg` VALUES ('52', '1000', '127.0.0.1', '2018-05-16 14:15:18', '10', '0');
INSERT INTO `loginmsg` VALUES ('53', '1000', '127.0.0.1', '2018-05-16 14:50:08', '10', '0');
INSERT INTO `loginmsg` VALUES ('54', '1000', '127.0.0.1', '2018-05-16 15:00:26', '10', '0');
INSERT INTO `loginmsg` VALUES ('55', '1000', '127.0.0.1', '2018-05-16 17:50:20', '10', '0');
INSERT INTO `loginmsg` VALUES ('56', '1000', '127.0.0.1', '2018-05-16 19:34:50', '11', '0');
INSERT INTO `loginmsg` VALUES ('57', '1000', '127.0.0.1', '2018-05-16 19:35:02', '10', '0');
INSERT INTO `loginmsg` VALUES ('58', '1000', '127.0.0.1', '2018-05-16 21:07:00', '10', '0');
INSERT INTO `loginmsg` VALUES ('59', '1000', '127.0.0.1', '2018-05-16 22:57:38', '10', '0');
INSERT INTO `loginmsg` VALUES ('60', '1000', '127.0.0.1', '2018-05-17 11:21:16', '10', '0');
INSERT INTO `loginmsg` VALUES ('61', '1000', '127.0.0.1', '2018-05-17 12:45:19', '10', '0');
INSERT INTO `loginmsg` VALUES ('62', '1000', '127.0.0.1', '2018-05-17 14:34:47', '10', '0');
INSERT INTO `loginmsg` VALUES ('63', '1000', '127.0.0.1', '2018-05-17 15:43:35', '10', '0');
INSERT INTO `loginmsg` VALUES ('64', '1000', '127.0.0.1', '2018-05-18 10:38:39', '10', '0');
INSERT INTO `loginmsg` VALUES ('65', '1000', '127.0.0.1', '2018-05-18 13:25:21', '10', '0');
INSERT INTO `loginmsg` VALUES ('66', '1000', '127.0.0.1', '2018-05-18 13:53:59', '10', '0');
INSERT INTO `loginmsg` VALUES ('67', '1000', '127.0.0.1', '2018-05-18 14:47:43', '10', '0');
INSERT INTO `loginmsg` VALUES ('68', '1000', '127.0.0.1', '2018-05-18 14:54:29', '10', '0');
INSERT INTO `loginmsg` VALUES ('69', '1000', '127.0.0.1', '2018-05-18 14:58:57', '10', '0');
INSERT INTO `loginmsg` VALUES ('70', '1000', '127.0.0.1', '2018-05-18 16:57:06', '10', '0');
INSERT INTO `loginmsg` VALUES ('71', '1000', '127.0.0.1', '2018-05-18 20:57:44', '10', '0');
INSERT INTO `loginmsg` VALUES ('72', '1000', '127.0.0.1', '2018-05-18 21:03:30', '10', '0');
INSERT INTO `loginmsg` VALUES ('73', '1000', '127.0.0.1', '2018-05-18 21:22:01', '11', '0');
INSERT INTO `loginmsg` VALUES ('74', '1000', '127.0.0.1', '2018-05-18 21:22:21', '10', '0');
INSERT INTO `loginmsg` VALUES ('75', '1000', '127.0.0.1', '2018-05-18 21:59:30', '10', '0');
INSERT INTO `loginmsg` VALUES ('76', '1000', '127.0.0.1', '2018-05-18 22:35:38', '10', '0');
INSERT INTO `loginmsg` VALUES ('77', '1000', '127.0.0.1', '2018-05-18 23:02:43', '10', '0');
INSERT INTO `loginmsg` VALUES ('78', '1000', '127.0.0.1', '2018-05-18 23:11:33', '11', '0');
INSERT INTO `loginmsg` VALUES ('79', '1000', '127.0.0.1', '2018-05-18 23:11:46', '11', '0');
INSERT INTO `loginmsg` VALUES ('80', '1000', '127.0.0.1', '2018-05-18 23:11:54', '11', '0');
INSERT INTO `loginmsg` VALUES ('81', '1000', '127.0.0.1', '2018-05-18 23:12:04', '10', '0');
INSERT INTO `loginmsg` VALUES ('82', '1000', '127.0.0.1', '2018-05-18 23:20:15', '10', '0');
INSERT INTO `loginmsg` VALUES ('83', '1000', '127.0.0.1', '2018-05-18 23:42:53', '10', '0');
INSERT INTO `loginmsg` VALUES ('84', '1000', '127.0.0.1', '2018-05-18 23:49:35', '11', '0');
INSERT INTO `loginmsg` VALUES ('85', '1000', '127.0.0.1', '2018-05-18 23:49:41', '10', '0');
INSERT INTO `loginmsg` VALUES ('86', '1000', '127.0.0.1', '2018-05-19 11:17:59', '10', '0');
INSERT INTO `loginmsg` VALUES ('87', '1000', '127.0.0.1', '2018-05-19 11:49:40', '10', '0');
INSERT INTO `loginmsg` VALUES ('88', '1000', '127.0.0.1', '2018-05-19 14:29:01', '10', '0');
INSERT INTO `loginmsg` VALUES ('89', '1000', '127.0.0.1', '2018-05-19 14:40:06', '10', '0');
INSERT INTO `loginmsg` VALUES ('90', '1000', '127.0.0.1', '2018-05-19 16:12:51', '10', '0');
INSERT INTO `loginmsg` VALUES ('91', '1000', '127.0.0.1', '2018-05-19 16:35:59', '10', '0');
INSERT INTO `loginmsg` VALUES ('92', '1000', '127.0.0.1', '2018-05-19 16:43:40', '10', '0');
INSERT INTO `loginmsg` VALUES ('93', '1000', '127.0.0.1', '2018-05-19 17:26:58', '10', '0');
INSERT INTO `loginmsg` VALUES ('94', '1000', '127.0.0.1', '2018-05-19 17:49:48', '10', '0');
INSERT INTO `loginmsg` VALUES ('95', '1000', '127.0.0.1', '2018-05-19 21:11:49', '11', '0');
INSERT INTO `loginmsg` VALUES ('96', '1000', '127.0.0.1', '2018-05-19 21:11:57', '10', '0');
INSERT INTO `loginmsg` VALUES ('97', '1000', '127.0.0.1', '2018-05-19 21:46:37', '11', '0');
INSERT INTO `loginmsg` VALUES ('98', '1000', '127.0.0.1', '2018-05-19 21:46:45', '10', '0');
INSERT INTO `loginmsg` VALUES ('99', '1000', '127.0.0.1', '2018-05-19 21:53:52', '10', '0');
INSERT INTO `loginmsg` VALUES ('100', '1000', '127.0.0.1', '2018-05-19 22:04:41', '10', '0');
INSERT INTO `loginmsg` VALUES ('101', '1000', '127.0.0.1', '2018-05-19 23:32:49', '10', '0');
INSERT INTO `loginmsg` VALUES ('102', '1000', '127.0.0.1', '2018-05-19 23:52:57', '10', '0');
INSERT INTO `loginmsg` VALUES ('103', '1000', '127.0.0.1', '2018-05-19 23:58:27', '10', '0');
INSERT INTO `loginmsg` VALUES ('104', '1000', '127.0.0.1', '2018-05-20 00:04:33', '10', '0');
INSERT INTO `loginmsg` VALUES ('105', '1000', '127.0.0.1', '2018-05-20 00:12:02', '10', '0');
INSERT INTO `loginmsg` VALUES ('106', '1601061526', '127.0.0.1', '2018-05-20 12:32:56', '10', '0');
INSERT INTO `loginmsg` VALUES ('107', '1601061526', '127.0.0.1', '2018-05-20 13:01:24', '10', '0');
INSERT INTO `loginmsg` VALUES ('108', '1000', '127.0.0.1', '2018-05-20 13:31:56', '10', '0');
INSERT INTO `loginmsg` VALUES ('109', '1601061526', '127.0.0.1', '2018-05-20 13:52:35', '10', '0');
INSERT INTO `loginmsg` VALUES ('110', '1000', '127.0.0.1', '2018-05-20 13:53:19', '11', '0');
INSERT INTO `loginmsg` VALUES ('111', '1000', '127.0.0.1', '2018-05-20 13:53:32', '10', '0');
INSERT INTO `loginmsg` VALUES ('112', '1601061526', '127.0.0.1', '2018-05-20 13:54:31', '10', '0');
INSERT INTO `loginmsg` VALUES ('113', '1601061526', '127.0.0.1', '2018-05-20 13:59:27', '10', '0');
INSERT INTO `loginmsg` VALUES ('114', '1000', '127.0.0.1', '2018-05-20 14:09:54', '10', '0');
INSERT INTO `loginmsg` VALUES ('115', '1601061526', '127.0.0.1', '2018-05-20 14:10:21', '10', '0');
INSERT INTO `loginmsg` VALUES ('116', '1000', '127.0.0.1', '2018-05-20 15:08:59', '10', '0');
INSERT INTO `loginmsg` VALUES ('117', '1601061526', '127.0.0.1', '2018-05-20 15:09:45', '10', '0');
INSERT INTO `loginmsg` VALUES ('118', '1601061526', '127.0.0.1', '2018-05-20 15:53:37', '10', '0');
INSERT INTO `loginmsg` VALUES ('119', '1601061526', '127.0.0.1', '2018-05-20 16:46:08', '10', '0');
INSERT INTO `loginmsg` VALUES ('120', '1000', '127.0.0.1', '2018-05-20 19:30:13', '10', '0');
INSERT INTO `loginmsg` VALUES ('121', '1601061526', '127.0.0.1', '2018-05-20 19:58:52', '10', '0');
INSERT INTO `loginmsg` VALUES ('122', '1601061526', '127.0.0.1', '2018-05-20 20:19:32', '10', '0');
INSERT INTO `loginmsg` VALUES ('123', '1601061526', '127.0.0.1', '2018-05-20 20:25:31', '10', '0');
INSERT INTO `loginmsg` VALUES ('124', '1601061526', '127.0.0.1', '2018-05-20 20:28:25', '11', '0');
INSERT INTO `loginmsg` VALUES ('125', '1601061526', '127.0.0.1', '2018-05-20 20:28:31', '11', '0');
INSERT INTO `loginmsg` VALUES ('126', '1601061526', '127.0.0.1', '2018-05-20 20:28:33', '10', '0');
INSERT INTO `loginmsg` VALUES ('127', '1601061526', '127.0.0.1', '2018-05-20 22:03:46', '10', '0');
INSERT INTO `loginmsg` VALUES ('128', '1601061526', '127.0.0.1', '2018-05-20 22:24:17', '10', '0');
INSERT INTO `loginmsg` VALUES ('129', '1908', '127.0.0.1', '2018-05-20 23:26:08', '10', '0');
INSERT INTO `loginmsg` VALUES ('130', '1908', '127.0.0.1', '2018-05-21 00:09:34', '10', '0');
INSERT INTO `loginmsg` VALUES ('131', '1908', '127.0.0.1', '2018-05-21 00:11:28', '10', '0');
INSERT INTO `loginmsg` VALUES ('132', '1000', '127.0.0.1', '2018-05-21 00:16:58', '10', '0');
INSERT INTO `loginmsg` VALUES ('133', '1908', '127.0.0.1', '2018-05-21 00:29:06', '10', '0');
INSERT INTO `loginmsg` VALUES ('134', '1908', '127.0.0.1', '2018-05-21 10:39:54', '10', '0');
INSERT INTO `loginmsg` VALUES ('135', '1601061501', '127.0.0.1', '2018-05-21 10:57:30', '10', '0');
INSERT INTO `loginmsg` VALUES ('136', '1601061508', '127.0.0.1', '2018-05-21 11:00:51', '10', '0');
INSERT INTO `loginmsg` VALUES ('137', '1601061520', '127.0.0.1', '2018-05-21 11:03:01', '10', '0');
INSERT INTO `loginmsg` VALUES ('138', '1601061521', '127.0.0.1', '2018-05-21 11:46:48', '11', '0');
INSERT INTO `loginmsg` VALUES ('139', '1601061521', '127.0.0.1', '2018-05-21 11:46:55', '10', '0');
INSERT INTO `loginmsg` VALUES ('140', '1601061522', '127.0.0.1', '2018-05-21 11:48:31', '10', '0');
INSERT INTO `loginmsg` VALUES ('141', '1601061527', '127.0.0.1', '2018-05-21 11:50:03', '10', '0');
INSERT INTO `loginmsg` VALUES ('142', '1601061530', '127.0.0.1', '2018-05-21 11:51:06', '10', '0');
INSERT INTO `loginmsg` VALUES ('143', '1000', '127.0.0.1', '2018-05-21 12:33:55', '10', '0');
INSERT INTO `loginmsg` VALUES ('144', '1000', '127.0.0.1', '2018-05-21 15:13:58', '10', '0');
INSERT INTO `loginmsg` VALUES ('145', '10002', '127.0.0.1', '2018-05-21 15:18:48', '10', '0');
INSERT INTO `loginmsg` VALUES ('146', '1908', '127.0.0.1', '2018-05-21 15:39:43', '10', '0');
INSERT INTO `loginmsg` VALUES ('147', '1908', '127.0.0.1', '2018-05-21 15:42:45', '10', '0');
INSERT INTO `loginmsg` VALUES ('148', '1908', '127.0.0.1', '2018-05-21 15:45:01', '10', '0');
INSERT INTO `loginmsg` VALUES ('149', '1908', '127.0.0.1', '2018-05-21 15:53:29', '10', '0');
INSERT INTO `loginmsg` VALUES ('150', '1908', '127.0.0.1', '2018-05-21 15:55:02', '10', '0');
INSERT INTO `loginmsg` VALUES ('151', '1908', '127.0.0.1', '2018-05-21 15:57:12', '10', '0');
INSERT INTO `loginmsg` VALUES ('152', '1908', '127.0.0.1', '2018-05-21 16:23:15', '10', '0');
INSERT INTO `loginmsg` VALUES ('153', '1908', '127.0.0.1', '2018-05-21 17:07:37', '10', '0');
INSERT INTO `loginmsg` VALUES ('154', '1000', '127.0.0.1', '2018-05-21 17:28:27', '10', '0');
INSERT INTO `loginmsg` VALUES ('155', '1000', '127.0.0.1', '2018-05-21 18:13:17', '10', '0');
INSERT INTO `loginmsg` VALUES ('156', '1000', '127.0.0.1', '2018-05-21 18:13:47', '10', '0');
INSERT INTO `loginmsg` VALUES ('157', '1000', '127.0.0.1', '2018-05-21 18:25:39', '10', '0');
INSERT INTO `loginmsg` VALUES ('158', '1908', '127.0.0.1', '2018-05-21 19:07:19', '11', '0');
INSERT INTO `loginmsg` VALUES ('159', '1908', '127.0.0.1', '2018-05-21 19:07:28', '10', '0');
INSERT INTO `loginmsg` VALUES ('160', '1908', '127.0.0.1', '2018-05-21 19:10:11', '10', '0');
INSERT INTO `loginmsg` VALUES ('161', '1000', '127.0.0.1', '2018-05-21 19:11:56', '10', '0');
INSERT INTO `loginmsg` VALUES ('162', '1000', '127.0.0.1', '2018-05-21 19:43:49', '10', '0');
INSERT INTO `loginmsg` VALUES ('163', '1000', '127.0.0.1', '2018-05-21 19:47:24', '10', '0');
INSERT INTO `loginmsg` VALUES ('164', '1000', '127.0.0.1', '2018-05-21 20:24:21', '10', '0');
INSERT INTO `loginmsg` VALUES ('165', '1000', '127.0.0.1', '2018-05-21 20:43:33', '10', '0');
INSERT INTO `loginmsg` VALUES ('166', '1908', '127.0.0.1', '2018-05-21 21:13:54', '10', '0');
INSERT INTO `loginmsg` VALUES ('167', '1908', '127.0.0.1', '2018-05-21 21:31:41', '10', '0');
INSERT INTO `loginmsg` VALUES ('168', '1908', '127.0.0.1', '2018-05-21 21:33:54', '10', '0');
INSERT INTO `loginmsg` VALUES ('169', '1908', '127.0.0.1', '2018-05-21 21:42:52', '11', '0');
INSERT INTO `loginmsg` VALUES ('170', '1908', '127.0.0.1', '2018-05-21 21:43:03', '10', '0');
INSERT INTO `loginmsg` VALUES ('171', '1908', '127.0.0.1', '2018-05-21 21:48:04', '10', '0');
INSERT INTO `loginmsg` VALUES ('172', '1000', '127.0.0.1', '2018-05-21 21:52:57', '10', '0');
INSERT INTO `loginmsg` VALUES ('173', '1908', '127.0.0.1', '2018-05-21 21:54:21', '10', '0');
INSERT INTO `loginmsg` VALUES ('174', '1908', '127.0.0.1', '2018-05-21 21:55:33', '10', '0');
INSERT INTO `loginmsg` VALUES ('175', '1908', '127.0.0.1', '2018-05-21 22:00:19', '10', '0');
INSERT INTO `loginmsg` VALUES ('176', '1601061526', '127.0.0.1', '2018-05-21 22:24:46', '10', '0');
INSERT INTO `loginmsg` VALUES ('177', '1000', '127.0.0.1', '2018-05-23 10:46:54', '10', '0');
INSERT INTO `loginmsg` VALUES ('178', '1601061526', '127.0.0.1', '2018-05-23 12:33:14', '10', '0');
INSERT INTO `loginmsg` VALUES ('179', '1908', '127.0.0.1', '2018-05-23 12:37:15', '10', '0');
INSERT INTO `loginmsg` VALUES ('180', '1000', '127.0.0.1', '2018-05-23 13:03:39', '10', '0');
INSERT INTO `loginmsg` VALUES ('181', '1000', '127.0.0.1', '2018-05-23 13:14:16', '10', '0');
INSERT INTO `loginmsg` VALUES ('182', '1000', '127.0.0.1', '2018-05-24 10:03:01', '10', '0');
INSERT INTO `loginmsg` VALUES ('183', '1601061526', '127.0.0.1', '2018-05-24 10:26:09', '10', '0');
INSERT INTO `loginmsg` VALUES ('184', '1908', '127.0.0.1', '2018-05-24 10:26:42', '10', '0');
INSERT INTO `loginmsg` VALUES ('185', '1000', '127.0.0.1', '2018-05-24 17:03:06', '10', '0');
INSERT INTO `loginmsg` VALUES ('186', '1908', '127.0.0.1', '2018-05-24 17:09:17', '10', '0');
INSERT INTO `loginmsg` VALUES ('187', '1601061526', '127.0.0.1', '2018-05-24 17:10:45', '10', '0');
INSERT INTO `loginmsg` VALUES ('188', '1908', '127.0.0.1', '2018-06-01 22:32:02', '10', '0');
INSERT INTO `loginmsg` VALUES ('189', '1000', '127.0.0.1', '2018-06-01 22:40:32', '10', '0');
INSERT INTO `loginmsg` VALUES ('190', '1601061526', '127.0.0.1', '2018-06-02 20:59:05', '10', '0');
INSERT INTO `loginmsg` VALUES ('191', '1908', '127.0.0.1', '2018-06-02 21:45:36', '10', '0');
INSERT INTO `loginmsg` VALUES ('192', '1000', '127.0.0.1', '2018-06-02 22:56:24', '10', '0');
INSERT INTO `loginmsg` VALUES ('193', '1601061526', '127.0.0.1', '2018-06-05 11:05:37', '11', '0');
INSERT INTO `loginmsg` VALUES ('194', '1601061526', '127.0.0.1', '2018-06-05 11:06:01', '10', '0');
INSERT INTO `loginmsg` VALUES ('195', '1000', '127.0.0.1', '2018-06-05 11:07:18', '10', '0');
INSERT INTO `loginmsg` VALUES ('196', '1908', '127.0.0.1', '2018-06-06 10:05:25', '10', '0');
INSERT INTO `loginmsg` VALUES ('197', '1000', '127.0.0.1', '2018-06-06 10:19:12', '10', '0');
INSERT INTO `loginmsg` VALUES ('198', '1601061526', '127.0.0.1', '2018-06-06 12:59:32', '10', '0');
INSERT INTO `loginmsg` VALUES ('199', '1908', '127.0.0.1', '2018-06-06 16:38:55', '10', '0');
INSERT INTO `loginmsg` VALUES ('200', '1000', '127.0.0.1', '2018-06-06 18:02:43', '10', '0');
INSERT INTO `loginmsg` VALUES ('201', '1908', '127.0.0.1', '2018-06-18 15:33:12', '10', '0');
INSERT INTO `loginmsg` VALUES ('202', '1000', '127.0.0.1', '2018-06-18 15:34:16', '10', '0');
INSERT INTO `loginmsg` VALUES ('203', '1601061526', '127.0.0.1', '2018-06-18 15:34:44', '11', '0');
INSERT INTO `loginmsg` VALUES ('204', '1601061526', '127.0.0.1', '2018-06-18 15:34:56', '10', '0');

-- ----------------------------
-- Table structure for `questions`
-- ----------------------------
DROP TABLE IF EXISTS `questions`;
CREATE TABLE `questions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` varchar(255) NOT NULL COMMENT '试题内容',
  `qtypeId` int(11) NOT NULL COMMENT '试题类型',
  `subjectId` int(11) NOT NULL COMMENT '学科Id',
  `result` int(11) NOT NULL COMMENT '试题结果',
  `version` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `type_fk_1` (`qtypeId`),
  KEY `sub_fk_2` (`subjectId`),
  KEY `res_fk_3` (`result`),
  CONSTRAINT `res_fk_3` FOREIGN KEY (`result`) REFERENCES `dict` (`id`),
  CONSTRAINT `sub_fk_2` FOREIGN KEY (`subjectId`) REFERENCES `subject` (`id`),
  CONSTRAINT `type_fk_1` FOREIGN KEY (`qtypeId`) REFERENCES `dict` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of questions
-- ----------------------------
INSERT INTO `questions` VALUES ('24', '若把操作系统看作是计算机资源的管理者，下列（）不属于操作系统所管理的资源。', '18', '1', '17', '0');
INSERT INTO `questions` VALUES ('25', '处理器执行的指令被分成两类，其中有一类称为特权指令，它只允许（）使用', '18', '1', '16', '0');
INSERT INTO `questions` VALUES ('26', '操作系统是一种（    ）。', '18', '1', '15', '1');
INSERT INTO `questions` VALUES ('27', '采用动态重定位方式装入的作业，在执行中允许（    ）将其移动。', '18', '1', '15', '0');
INSERT INTO `questions` VALUES ('28', '位示图方法可用于（    ）。', '18', '1', '16', '0');
INSERT INTO `questions` VALUES ('29', '操作系统处理缺页中断时，选择一种好的调度算法对主存和辅存中信息进行高效调度，尽可能地避免（    ）。', '18', '1', '14', '0');
INSERT INTO `questions` VALUES ('30', '存储管理主要管理的是（    ）。', '18', '1', '16', '0');
INSERT INTO `questions` VALUES ('31', '在固定分区分配中，每个分区的大小是（    ）。', '18', '1', '16', '0');
INSERT INTO `questions` VALUES ('32', '下列算法中用于磁盘移臂调度的是（    ）。', '18', '1', '15', '0');
INSERT INTO `questions` VALUES ('33', '在采用Spooling技术的系统中，用户的打印数据首先被送到（    ）。', '18', '1', '14', '0');
INSERT INTO `questions` VALUES ('34', '主存与外存进行信息交换的物理单位是（    ）。', '18', '1', '17', '0');
INSERT INTO `questions` VALUES ('35', '下面有关进程的描述中，错误的是（    ）。', '18', '1', '15', '0');
INSERT INTO `questions` VALUES ('36', '分页式存储管理中，地址转换工作是由（    ）完成的。', '18', '1', '14', '0');
INSERT INTO `questions` VALUES ('37', '下面设备中，一次只能让一个作业独占使用的设备是（    ）。', '18', '1', '15', '0');
INSERT INTO `questions` VALUES ('38', '如果允许不同用户的文件可以具有相同的文件名，通常采用（    ）来保证按名存取的安全', '18', '1', '17', '0');
INSERT INTO `questions` VALUES ('39', '临界段是指并发进程中访问临界资源的（    ）段。', '18', '1', '17', '0');
INSERT INTO `questions` VALUES ('40', '（    ）存储管理兼顾了段式在逻辑上清晰和页式在存储管理上方便的优点。', '18', '1', '16', '0');
INSERT INTO `questions` VALUES ('41', '（    ）是由硬件设计时固定的。', '18', '1', '16', '0');
INSERT INTO `questions` VALUES ('42', '（    ）是操作系统中采用的以空间换时间的技术。', '18', '1', '14', '0');
INSERT INTO `questions` VALUES ('43', '两个进程合作完成一个任务，在并发执行中，一个进程要等待合作伙伴发来消息，或者建立某个条件后再向前执行，这种关系是进程间的（    ）。', '18', '1', '14', '0');
INSERT INTO `questions` VALUES ('44', '操作系统的基本类型主要有批处理操作系统、分时操作系统及实时操作系统。', '19', '1', '20', '1');
INSERT INTO `questions` VALUES ('45', '若信号量S的初值为2，且有三个进程共享此信号量，则S的取值范围是[0，2]。', '19', '1', '21', '0');
INSERT INTO `questions` VALUES ('46', '分区管理要求对每一个作业都分配地址连续主存单元。', '19', '1', '20', '0');
INSERT INTO `questions` VALUES ('47', '所谓多道程序设计是指将一个以上的作业放入主存，并且同时处于运行状态，这些作业共享处理机和外围设备等其他资源。', '19', '1', '20', '0');
INSERT INTO `questions` VALUES ('48', '进程的组成部分中PCB是进程存在的惟一标志。', '19', '1', '20', '0');
INSERT INTO `questions` VALUES ('49', '进程变化状态中，阻塞→就绪变化是不可能发生的。', '19', '1', '21', '0');
INSERT INTO `questions` VALUES ('50', '周转时间是指从作业提交给系统到作业完成时间间隔。', '19', '1', '20', '0');
INSERT INTO `questions` VALUES ('51', '树型目录结构中的第一级目录常被称作叶目录。', '19', '1', '21', '0');
INSERT INTO `questions` VALUES ('52', '在资源数大大小于进程数或者进程同时申请的资源数大大超过资源总数的情况下，系统出现死锁。', '19', '1', '21', '0');
INSERT INTO `questions` VALUES ('53', '某一进程运行时因缺乏资源进入阻塞状态，要进行进程调度。', '19', '1', '20', '0');
INSERT INTO `questions` VALUES ('54', '既考虑作业等待时间，又考虑作业执行时间的调度算法是先来先服务。', '19', '1', '21', '0');
INSERT INTO `questions` VALUES ('55', '文件系统中，顺序文件的逻辑文件中记录顺序与物理文件中占用物理块顺序一致。', '19', '1', '20', '0');
INSERT INTO `questions` VALUES ('56', '每个扇区中信息的传送时间是相同的，但传送信息所需的时间是无法固定的', '19', '1', '21', '0');
INSERT INTO `questions` VALUES ('57', '磁带上的文件一般只能随机存取。', '19', '1', '21', '0');
INSERT INTO `questions` VALUES ('58', '用户请求使用一个已存在的文件时，其正确的操作次序为读/写→关闭。', '19', '1', '21', '0');
INSERT INTO `questions` VALUES ('59', '如果I/O设备与存储设备进行数据交换不经过CPU来完成，这种数据交换方式是DMA方式。', '19', '1', '20', '0');
INSERT INTO `questions` VALUES ('60', '时间片轮转调度算法经常用于批处理系统。', '19', '1', '21', '0');
INSERT INTO `questions` VALUES ('61', '除了可以采用资源剥夺法解除死锁，还可以采用拒绝分配新的资源方法解除死锁。', '19', '1', '21', '0');
INSERT INTO `questions` VALUES ('62', '为了使A、B两个进程互斥地访问单个缓冲区，应为设置一个互斥信号量S，初值为1，相应的P(S)、V(S)作必须分别安排在两进程的临界区的两端。', '19', '1', '20', '0');
INSERT INTO `questions` VALUES ('63', '计算机操作系统由硬件子系统和软件子系统。', '19', '1', '20', '0');
INSERT INTO `questions` VALUES ('64', 'C语言的基本构成单位是：() 。', '18', '2', '14', '0');
INSERT INTO `questions` VALUES ('65', '一个C语言程序总是从（）开始执行。', '18', '2', '15', '0');
INSERT INTO `questions` VALUES ('66', 'C语言的程序一行写不下时，可以（）。', '18', '2', '16', '0');
INSERT INTO `questions` VALUES ('69', '以下不正确的C语言标识符是（）', '18', '2', '17', '0');
INSERT INTO `questions` VALUES ('70', '下列字符串是标识符的是：（）。', '18', '2', '16', '0');
INSERT INTO `questions` VALUES ('71', 'C语言程序总是从main()函数开始执行', '19', '2', '21', '0');
INSERT INTO `questions` VALUES ('72', 'C语言程序总是从第一个定义的函数开始执行', '19', '2', '21', '0');
INSERT INTO `questions` VALUES ('73', '在C语言程序中，要调用的函数必须放在main()函数中定义', '19', '2', '21', '0');
INSERT INTO `questions` VALUES ('74', 'C语言程序中的main()函数必须放在程序的开始部分', '19', '1', '20', '0');
INSERT INTO `questions` VALUES ('75', 'C语言中，字符型数据在内存中以（）形式存放。', '18', '2', '17', '0');
INSERT INTO `questions` VALUES ('77', '以下关于数组的描述正确的是（）', '18', '2', '16', '0');
INSERT INTO `questions` VALUES ('78', '在定义int a[10];之后，对a的引用正确的是', '18', '2', '14', '0');
INSERT INTO `questions` VALUES ('79', '在执行int a[][3]={1,2,3,4,5,6};语句后，a[1][0]的值是        。', '18', '2', '14', '1');
INSERT INTO `questions` VALUES ('80', '在C语言中，当函数调用时（）', '18', '2', '15', '1');
INSERT INTO `questions` VALUES ('81', '果在一个函数的复合语句中定义了一个变量，则该变量 () 。', '18', '2', '14', '0');
INSERT INTO `questions` VALUES ('82', 'C语言允许函数值类型缺省定义，此时该函数值隐含的类型是（）', '18', '2', '15', '0');
INSERT INTO `questions` VALUES ('83', 'C语言规定，函数返回值的类型是由()', '18', '2', '17', '0');
INSERT INTO `questions` VALUES ('84', '在C语言程序中，以下描述正确的是（）。', '18', '2', '17', '0');
INSERT INTO `questions` VALUES ('85', '当调用函数时，实参是一个数组名，则向函数传送的是', '18', '2', '15', '0');
INSERT INTO `questions` VALUES ('86', '在调用函数时，如果实参是简单变量，它与对应形参之间的数据传递方式是()', '18', '2', '15', '0');
INSERT INTO `questions` VALUES ('87', '在C语言中,为了结束由do-while语句构成的循环, while后一对圆括号中表达式的值应该是0.', '19', '2', '20', '0');
INSERT INTO `questions` VALUES ('88', '对指针变量的初始化int a,*pa=', '19', '2', '20', '0');
INSERT INTO `questions` VALUES ('89', '在C程序中,无论是整数还是实数,都能准确无误地表示', '19', '2', '21', '0');
INSERT INTO `questions` VALUES ('90', '程序中的变量代表内存中的一个存储单元,它的值不可以随时修改.', '19', '2', '21', '0');
INSERT INTO `questions` VALUES ('91', '字符处理函数strcpy(str1,str2)的功能是把字符串1接到字符串2的后面.', '19', '2', '20', '0');
INSERT INTO `questions` VALUES ('92', 'C语言中只能逐个引用数组元素而不能一次引用整个数组.', '19', '2', '20', '0');
INSERT INTO `questions` VALUES ('93', '0x173是\"正确\"的十六进制常数', '19', '2', '20', '0');
INSERT INTO `questions` VALUES ('94', '将整数以二进制形式存盘比以ASCII形式存盘省空间、运算快', '19', '2', '20', '0');
INSERT INTO `questions` VALUES ('95', 'if后面的控制表达式可以不用括号括起来.', '19', '2', '21', '0');
INSERT INTO `questions` VALUES ('96', '同一数组的元素在内存中存储是连续存放的,占有连续的存储单元.', '19', '2', '21', '0');
INSERT INTO `questions` VALUES ('97', 'sqrt(m)是求m平方的函数.', '19', '2', '21', '0');
INSERT INTO `questions` VALUES ('98', 'C程序中的关键字必须小写,其他标识符不区分大小写.', '19', '2', '21', '0');
INSERT INTO `questions` VALUES ('99', '开关语句switch最多可形成三个分支.', '19', '2', '21', '0');
INSERT INTO `questions` VALUES ('100', 'C语言规定,在一个源程序中,main函数的必须在最开始', '19', '2', '21', '0');
INSERT INTO `questions` VALUES ('101', '在调用函数时,实参把值传送给对应位置上的形参,形参的值不能传给实参.', '19', '2', '20', '0');
INSERT INTO `questions` VALUES ('102', '数组定义 int a[10]; 占内存10个字节.', '19', '2', '21', '0');

-- ----------------------------
-- Table structure for `selected`
-- ----------------------------
DROP TABLE IF EXISTS `selected`;
CREATE TABLE `selected` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `qid` int(11) NOT NULL COMMENT '试题ID',
  `sid` int(11) NOT NULL COMMENT '选项',
  `content` varchar(255) NOT NULL COMMENT '选项内容',
  `version` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `qu_fk_1` (`qid`),
  KEY `s_fk_2` (`sid`),
  CONSTRAINT `qu_fk_1` FOREIGN KEY (`qid`) REFERENCES `questions` (`id`),
  CONSTRAINT `s_fk_2` FOREIGN KEY (`sid`) REFERENCES `dict` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=187 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of selected
-- ----------------------------
INSERT INTO `selected` VALUES ('33', '24', '14', '磁盘', '0');
INSERT INTO `selected` VALUES ('34', '24', '15', '内存', '0');
INSERT INTO `selected` VALUES ('35', '24', '16', 'CPU', '0');
INSERT INTO `selected` VALUES ('36', '24', '17', '中断', '0');
INSERT INTO `selected` VALUES ('37', '25', '14', '操作员', '0');
INSERT INTO `selected` VALUES ('38', '25', '15', '联机用户', '0');
INSERT INTO `selected` VALUES ('39', '25', '16', '操作系统 ', '0');
INSERT INTO `selected` VALUES ('40', '25', '17', '目标程序', '0');
INSERT INTO `selected` VALUES ('41', '26', '14', '系统硬件', '1');
INSERT INTO `selected` VALUES ('42', '26', '15', '系统软件', '1');
INSERT INTO `selected` VALUES ('43', '26', '16', '应用软件', '1');
INSERT INTO `selected` VALUES ('44', '26', '17', '支援软件', '1');
INSERT INTO `selected` VALUES ('45', '27', '14', '用户有条件地 ', '0');
INSERT INTO `selected` VALUES ('46', '27', '15', '操作系统有条件地', '0');
INSERT INTO `selected` VALUES ('47', '27', '16', '用户无条件地', '0');
INSERT INTO `selected` VALUES ('48', '27', '17', '操作系统无条件地', '0');
INSERT INTO `selected` VALUES ('49', '28', '14', '磁盘的驱动调度', '0');
INSERT INTO `selected` VALUES ('50', '28', '15', '磁盘的驱动调度', '0');
INSERT INTO `selected` VALUES ('51', '28', '16', '磁盘空间管理', '0');
INSERT INTO `selected` VALUES ('52', '28', '17', '页式虚拟存贮管理中的页面调度', '0');
INSERT INTO `selected` VALUES ('53', '29', '14', '碎片', '0');
INSERT INTO `selected` VALUES ('54', '29', '15', 'CPU空闲', '0');
INSERT INTO `selected` VALUES ('55', '29', '16', '多重中断', '0');
INSERT INTO `selected` VALUES ('56', '29', '17', '抖动', '0');
INSERT INTO `selected` VALUES ('57', '30', '14', '外存存储器用户区', '0');
INSERT INTO `selected` VALUES ('58', '30', '15', '外存存储器系统区', '0');
INSERT INTO `selected` VALUES ('59', '30', '16', '主存储器用户区', '0');
INSERT INTO `selected` VALUES ('60', '30', '17', '主存储器系统区', '0');
INSERT INTO `selected` VALUES ('61', '31', '14', '随作业长度变化', '0');
INSERT INTO `selected` VALUES ('62', '31', '15', '相同', '0');
INSERT INTO `selected` VALUES ('63', '31', '16', '可以不同但预先固定', '0');
INSERT INTO `selected` VALUES ('64', '31', '17', '可以不同但根据作业长度固定', '0');
INSERT INTO `selected` VALUES ('65', '32', '14', '时间片轮转法', '0');
INSERT INTO `selected` VALUES ('66', '32', '15', '最短寻找时间优先算法', '0');
INSERT INTO `selected` VALUES ('67', '32', '16', 'LRU算法', '0');
INSERT INTO `selected` VALUES ('68', '32', '17', '优先级高者优先算法', '0');
INSERT INTO `selected` VALUES ('69', '33', '14', '磁盘的输出井', '0');
INSERT INTO `selected` VALUES ('70', '33', '15', '磁盘的输入井', '0');
INSERT INTO `selected` VALUES ('71', '33', '16', '打印机', '0');
INSERT INTO `selected` VALUES ('72', '33', '17', '终端', '0');
INSERT INTO `selected` VALUES ('73', '34', '14', '数据项', '0');
INSERT INTO `selected` VALUES ('74', '34', '15', '卷', '0');
INSERT INTO `selected` VALUES ('75', '34', '16', '字节', '0');
INSERT INTO `selected` VALUES ('76', '34', '17', '块', '0');
INSERT INTO `selected` VALUES ('77', '35', '14', '进程是动态的概念', '0');
INSERT INTO `selected` VALUES ('78', '35', '15', '进程是指令的集合', '0');
INSERT INTO `selected` VALUES ('79', '35', '16', '进程是有生命周期的', '0');
INSERT INTO `selected` VALUES ('80', '35', '17', '进程执行需要处理机', '0');
INSERT INTO `selected` VALUES ('81', '36', '14', '硬件', '0');
INSERT INTO `selected` VALUES ('82', '36', '15', '地址转换程序', '0');
INSERT INTO `selected` VALUES ('83', '36', '16', '用户程序', '0');
INSERT INTO `selected` VALUES ('84', '36', '17', '装入程序', '0');
INSERT INTO `selected` VALUES ('85', '37', '14', '磁盘机', '0');
INSERT INTO `selected` VALUES ('86', '37', '15', '打印机', '0');
INSERT INTO `selected` VALUES ('87', '37', '16', '光驱', '0');
INSERT INTO `selected` VALUES ('88', '37', '17', '硬盘驱动器', '0');
INSERT INTO `selected` VALUES ('89', '38', '14', '重名翻译机构', '0');
INSERT INTO `selected` VALUES ('90', '38', '15', '建立索引表', '0');
INSERT INTO `selected` VALUES ('91', '38', '16', '建立指针', '0');
INSERT INTO `selected` VALUES ('92', '38', '17', '多级目录结构', '0');
INSERT INTO `selected` VALUES ('93', '39', '14', '管理信息', '0');
INSERT INTO `selected` VALUES ('94', '39', '15', '信息存储', '0');
INSERT INTO `selected` VALUES ('95', '39', '16', '数据', '0');
INSERT INTO `selected` VALUES ('96', '39', '17', '程序', '0');
INSERT INTO `selected` VALUES ('97', '40', '14', '分段', '0');
INSERT INTO `selected` VALUES ('98', '40', '15', '分页', '0');
INSERT INTO `selected` VALUES ('99', '40', '16', '段页式', '0');
INSERT INTO `selected` VALUES ('100', '40', '17', '可变分区方式', '0');
INSERT INTO `selected` VALUES ('101', '41', '14', '寻找时间', '0');
INSERT INTO `selected` VALUES ('102', '41', '15', '延迟时间', '0');
INSERT INTO `selected` VALUES ('103', '41', '16', '传送时间', '0');
INSERT INTO `selected` VALUES ('104', '41', '17', '优化时间', '0');
INSERT INTO `selected` VALUES ('105', '42', '14', '缓冲技术', '0');
INSERT INTO `selected` VALUES ('106', '42', '15', '并行技术', '0');
INSERT INTO `selected` VALUES ('107', '42', '16', '通道技术', '0');
INSERT INTO `selected` VALUES ('108', '42', '17', '虚拟存储技术', '0');
INSERT INTO `selected` VALUES ('109', '43', '14', '同步', '0');
INSERT INTO `selected` VALUES ('110', '43', '15', '互斥', '0');
INSERT INTO `selected` VALUES ('111', '43', '16', '竞争', '0');
INSERT INTO `selected` VALUES ('112', '43', '17', '合作', '0');
INSERT INTO `selected` VALUES ('113', '64', '14', '函数', '0');
INSERT INTO `selected` VALUES ('114', '64', '15', '函数和过程', '0');
INSERT INTO `selected` VALUES ('115', '64', '16', '超文本过程', '0');
INSERT INTO `selected` VALUES ('116', '64', '17', '子程序', '0');
INSERT INTO `selected` VALUES ('117', '65', '14', '主过程', '0');
INSERT INTO `selected` VALUES ('118', '65', '15', '主函数', '0');
INSERT INTO `selected` VALUES ('119', '65', '16', '子程序', '0');
INSERT INTO `selected` VALUES ('120', '65', '17', '主程序', '0');
INSERT INTO `selected` VALUES ('121', '66', '14', '用逗号换行', '0');
INSERT INTO `selected` VALUES ('122', '66', '15', '用分号换行', '0');
INSERT INTO `selected` VALUES ('123', '66', '16', '在任意一空格处换行', '0');
INSERT INTO `selected` VALUES ('124', '66', '17', '用回车符', '0');
INSERT INTO `selected` VALUES ('131', '69', '14', 'ABC', '0');
INSERT INTO `selected` VALUES ('132', '69', '15', 'abc', '0');
INSERT INTO `selected` VALUES ('133', '69', '16', 'a_bc', '0');
INSERT INTO `selected` VALUES ('134', '69', '17', 'ab.c', '0');
INSERT INTO `selected` VALUES ('135', '70', '14', '_HJ', '0');
INSERT INTO `selected` VALUES ('136', '70', '15', '9_student', '0');
INSERT INTO `selected` VALUES ('137', '70', '16', 'long', '0');
INSERT INTO `selected` VALUES ('138', '70', '17', 'LINE 1', '0');
INSERT INTO `selected` VALUES ('139', '75', '14', '原码', '0');
INSERT INTO `selected` VALUES ('140', '75', '15', 'BCD码', '0');
INSERT INTO `selected` VALUES ('141', '75', '16', '反码', '0');
INSERT INTO `selected` VALUES ('142', '75', '17', 'ASCII码', '0');
INSERT INTO `selected` VALUES ('147', '77', '14', '数组的大小是固定的，但可以有不同的类型的数组元素', '0');
INSERT INTO `selected` VALUES ('148', '77', '15', '数组的大小是可变的，但所有数组元素的类型必须相同。', '0');
INSERT INTO `selected` VALUES ('149', '77', '16', '数组的大小是固定的，但所有数组元素的类型必须相同。', '0');
INSERT INTO `selected` VALUES ('150', '77', '17', '数组的大小是可变的，但可以有不同的类型的数组元素。', '0');
INSERT INTO `selected` VALUES ('151', '78', '14', 'a[10]', '0');
INSERT INTO `selected` VALUES ('152', '78', '15', 'a[6.3]', '0');
INSERT INTO `selected` VALUES ('153', '78', '16', 'a(6)', '0');
INSERT INTO `selected` VALUES ('154', '78', '17', 'a[10-10]', '0');
INSERT INTO `selected` VALUES ('155', '79', '14', '4', '1');
INSERT INTO `selected` VALUES ('156', '79', '15', '1', '1');
INSERT INTO `selected` VALUES ('157', '79', '16', '5', '1');
INSERT INTO `selected` VALUES ('158', '79', '17', '3', '1');
INSERT INTO `selected` VALUES ('159', '80', '14', '实参和形参共用存储单元', '1');
INSERT INTO `selected` VALUES ('160', '80', '15', '实参和形参各占一个独立的存储单元', '1');
INSERT INTO `selected` VALUES ('161', '80', '16', '可以由用户指定实参和形参是否共用存储单元', '1');
INSERT INTO `selected` VALUES ('162', '80', '17', '由系统自动确定实参和形参是否共用存储单元', '1');
INSERT INTO `selected` VALUES ('163', '81', '14', '只在该符合语句中有效，在该符合语句外无效', '0');
INSERT INTO `selected` VALUES ('164', '81', '15', '在该函数中任何位置都有效', '0');
INSERT INTO `selected` VALUES ('165', '81', '16', '在本程序的原文件范围内均有效', '0');
INSERT INTO `selected` VALUES ('166', '81', '17', '此定义方法错误，其变量为非法变量', '0');
INSERT INTO `selected` VALUES ('167', '82', '14', 'float型', '0');
INSERT INTO `selected` VALUES ('168', '82', '15', 'int型', '0');
INSERT INTO `selected` VALUES ('169', '82', '16', 'long型', '0');
INSERT INTO `selected` VALUES ('170', '82', '17', 'double型', '0');
INSERT INTO `selected` VALUES ('171', '83', '14', 'return语句中的表达式类型所决定', '0');
INSERT INTO `selected` VALUES ('172', '83', '15', '调用该函数时的主调函数类型所决定', '0');
INSERT INTO `selected` VALUES ('173', '83', '16', '调用该函数时系统临时决定', '0');
INSERT INTO `selected` VALUES ('174', '83', '17', '在定义该函数时所指定的函数类型决定', '0');
INSERT INTO `selected` VALUES ('175', '84', '14', '函数的定义和函数的调用均不可以嵌套', '0');
INSERT INTO `selected` VALUES ('176', '84', '15', '函数的定义可以嵌套，但函数的调用不可以嵌套', '0');
INSERT INTO `selected` VALUES ('177', '84', '16', '函数的定义和函数的调用均可以嵌套', '0');
INSERT INTO `selected` VALUES ('178', '84', '17', '函数的定义不可以嵌套，但函数的调用可以嵌套', '0');
INSERT INTO `selected` VALUES ('179', '85', '14', '数组的长度', '0');
INSERT INTO `selected` VALUES ('180', '85', '15', '数组的首地址', '0');
INSERT INTO `selected` VALUES ('181', '85', '16', '数组每一个元素的地址', '0');
INSERT INTO `selected` VALUES ('182', '85', '17', '数组每个元素中的值', '0');
INSERT INTO `selected` VALUES ('183', '86', '14', '地址传递', '0');
INSERT INTO `selected` VALUES ('184', '86', '15', '单向值传递', '0');
INSERT INTO `selected` VALUES ('185', '86', '16', '由实参传给形，再由形参传回实参', '0');
INSERT INTO `selected` VALUES ('186', '86', '17', '传递方式由用户指定', '0');

-- ----------------------------
-- Table structure for `student`
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student` (
  `studentno` varchar(255) NOT NULL COMMENT '学号 ',
  `studentname` varchar(255) NOT NULL COMMENT '姓名',
  `version` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`studentno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO `student` VALUES ('1601061501', '啊啊啊', '0');
INSERT INTO `student` VALUES ('1601061508', '赵六', '0');
INSERT INTO `student` VALUES ('1601061520', '嘻嘻嘻', '0');
INSERT INTO `student` VALUES ('1601061521', '王五', '0');
INSERT INTO `student` VALUES ('1601061522', '李四', '0');
INSERT INTO `student` VALUES ('1601061526', '李四', '0');
INSERT INTO `student` VALUES ('1601061527', '张三', '0');
INSERT INTO `student` VALUES ('1601061530', '呵呵呵', '0');

-- ----------------------------
-- Table structure for `stu_exam`
-- ----------------------------
DROP TABLE IF EXISTS `stu_exam`;
CREATE TABLE `stu_exam` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stuId` varchar(11) NOT NULL COMMENT '学号',
  `examId` int(11) NOT NULL COMMENT '考试ID',
  `startTime` datetime DEFAULT NULL COMMENT '开始时间',
  `endTime` datetime DEFAULT NULL COMMENT '结束时间',
  `score` int(11) DEFAULT NULL COMMENT '试题分数',
  `version` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `stu_fk_1` (`stuId`),
  KEY `exam_fk_5` (`examId`),
  CONSTRAINT `exam_fk_5` FOREIGN KEY (`examId`) REFERENCES `exam` (`id`),
  CONSTRAINT `stu_fk_1` FOREIGN KEY (`stuId`) REFERENCES `student` (`studentno`)
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of stu_exam
-- ----------------------------
INSERT INTO `stu_exam` VALUES ('59', '1601061526', '1', '2018-05-20 22:45:15', '2018-05-20 22:45:43', '45', '1');
INSERT INTO `stu_exam` VALUES ('60', '1601061526', '2', '2018-05-20 22:47:16', '2018-05-20 22:47:46', '100', '5');
INSERT INTO `stu_exam` VALUES ('61', '1601061501', '1', '2018-05-21 10:57:57', '2018-05-21 10:58:27', '25', '1');
INSERT INTO `stu_exam` VALUES ('62', '1601061508', '1', '2018-05-21 11:01:04', '2018-05-21 11:01:42', '75', '1');
INSERT INTO `stu_exam` VALUES ('63', '1601061520', '1', '2018-05-21 11:03:09', '2018-05-21 11:07:31', '65', '1');
INSERT INTO `stu_exam` VALUES ('64', '1601061521', '1', '2018-05-21 11:47:01', '2018-05-21 11:47:44', '45', '1');
INSERT INTO `stu_exam` VALUES ('65', '1601061522', '1', '2018-05-21 11:48:37', '2018-05-21 11:49:09', '40', '1');
INSERT INTO `stu_exam` VALUES ('66', '1601061527', '1', '2018-05-21 11:50:10', '2018-05-21 11:50:39', '60', '1');
INSERT INTO `stu_exam` VALUES ('67', '1601061530', '1', '2018-05-21 11:51:12', '2018-05-21 11:51:36', '60', '1');
INSERT INTO `stu_exam` VALUES ('71', '1601061526', '4', '2018-05-23 12:35:07', '2018-05-23 12:35:44', '30', '1');
INSERT INTO `stu_exam` VALUES ('72', '1601061526', '3', '2018-06-05 11:11:58', null, null, '0');
INSERT INTO `stu_exam` VALUES ('73', '1601061526', '3', '2018-06-18 16:50:39', '2018-06-18 16:52:16', '30', '1');

-- ----------------------------
-- Table structure for `stu_exam_ques_result`
-- ----------------------------
DROP TABLE IF EXISTS `stu_exam_ques_result`;
CREATE TABLE `stu_exam_ques_result` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stu_examId` int(11) NOT NULL COMMENT '学生_试题ID',
  `exam_quesId` int(11) NOT NULL COMMENT '试卷_试题ID',
  `resultId` int(11) DEFAULT NULL COMMENT '试题结果',
  `version` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `s_fk_1` (`stu_examId`),
  KEY `e_fk_2` (`exam_quesId`),
  KEY `r_fk_3` (`resultId`),
  CONSTRAINT `e_fk_2` FOREIGN KEY (`exam_quesId`) REFERENCES `questions` (`id`),
  CONSTRAINT `r_fk_3` FOREIGN KEY (`resultId`) REFERENCES `dict` (`id`),
  CONSTRAINT `s_fk_1` FOREIGN KEY (`stu_examId`) REFERENCES `stu_exam` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=283 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of stu_exam_ques_result
-- ----------------------------
INSERT INTO `stu_exam_ques_result` VALUES ('43', '59', '24', '14', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('44', '59', '25', '15', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('45', '59', '26', '16', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('46', '59', '27', '17', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('47', '59', '30', '14', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('48', '59', '31', '15', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('49', '59', '32', '16', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('50', '59', '33', '17', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('51', '59', '34', '14', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('52', '59', '35', '15', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('53', '59', '44', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('54', '59', '45', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('55', '59', '46', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('56', '59', '47', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('57', '59', '48', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('58', '59', '49', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('59', '59', '51', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('60', '59', '52', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('61', '59', '53', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('62', '59', '54', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('63', '60', '24', '16', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('64', '60', '25', '15', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('65', '60', '26', '14', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('66', '60', '27', '16', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('67', '60', '28', '14', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('68', '60', '29', '15', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('69', '60', '30', '15', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('70', '60', '31', '14', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('71', '60', '32', '14', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('72', '60', '33', '16', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('73', '60', '49', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('74', '60', '50', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('75', '60', '51', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('76', '60', '52', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('77', '60', '53', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('78', '60', '54', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('79', '60', '55', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('80', '60', '56', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('81', '60', '57', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('82', '60', '58', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('83', '61', '24', '15', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('84', '61', '25', '15', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('85', '61', '26', '14', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('86', '61', '27', '16', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('87', '61', '30', '15', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('88', '61', '31', '14', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('89', '61', '32', '14', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('90', '61', '33', '16', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('91', '61', '34', '14', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('92', '61', '35', '16', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('93', '61', '44', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('94', '61', '45', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('95', '61', '46', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('96', '61', '47', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('97', '61', '48', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('98', '61', '49', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('99', '61', '51', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('100', '61', '52', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('101', '61', '53', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('102', '61', '54', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('103', '62', '24', '17', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('104', '62', '25', '16', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('105', '62', '26', '15', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('106', '62', '27', '15', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('107', '62', '30', '16', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('108', '62', '31', '16', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('109', '62', '32', '15', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('110', '62', '33', '14', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('111', '62', '34', '17', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('112', '62', '35', '15', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('113', '62', '44', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('114', '62', '45', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('115', '62', '46', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('116', '62', '47', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('117', '62', '48', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('118', '62', '49', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('119', '62', '51', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('120', '62', '52', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('121', '62', '53', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('122', '62', '54', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('123', '63', '24', '14', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('124', '63', '25', '14', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('125', '63', '26', '15', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('126', '63', '27', '15', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('127', '63', '30', '16', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('128', '63', '31', '14', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('129', '63', '32', '17', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('130', '63', '33', '17', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('131', '63', '34', '16', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('132', '63', '35', '15', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('133', '63', '44', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('134', '63', '45', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('135', '63', '46', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('136', '63', '47', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('137', '63', '48', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('138', '63', '49', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('139', '63', '51', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('140', '63', '52', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('141', '63', '53', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('142', '63', '54', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('143', '64', '24', '15', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('144', '64', '25', '14', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('145', '64', '26', '16', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('146', '64', '27', '16', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('147', '64', '30', '17', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('148', '64', '31', '15', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('149', '64', '32', '15', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('150', '64', '33', '14', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('151', '64', '34', '15', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('152', '64', '35', '16', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('153', '64', '44', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('154', '64', '45', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('155', '64', '46', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('156', '64', '47', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('157', '64', '48', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('158', '64', '49', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('159', '64', '51', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('160', '64', '52', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('161', '64', '53', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('162', '64', '54', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('163', '65', '24', '17', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('164', '65', '25', '16', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('165', '65', '26', '17', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('166', '65', '27', '17', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('167', '65', '30', '14', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('168', '65', '31', '14', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('169', '65', '32', '14', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('170', '65', '33', '14', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('171', '65', '34', '14', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('172', '65', '35', '14', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('173', '65', '44', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('174', '65', '45', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('175', '65', '46', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('176', '65', '47', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('177', '65', '48', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('178', '65', '49', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('179', '65', '51', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('180', '65', '52', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('181', '65', '53', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('182', '65', '54', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('183', '66', '24', '16', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('184', '66', '25', '14', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('185', '66', '26', '15', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('186', '66', '27', '15', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('187', '66', '30', '15', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('188', '66', '31', '15', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('189', '66', '32', '15', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('190', '66', '33', '15', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('191', '66', '34', '15', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('192', '66', '35', '15', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('193', '66', '44', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('194', '66', '45', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('195', '66', '46', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('196', '66', '47', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('197', '66', '48', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('198', '66', '49', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('199', '66', '51', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('200', '66', '52', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('201', '66', '53', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('202', '66', '54', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('203', '67', '24', '17', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('204', '67', '25', '16', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('205', '67', '26', '16', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('206', '67', '27', '15', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('207', '67', '30', '15', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('208', '67', '31', '16', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('209', '67', '32', '16', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('210', '67', '33', '17', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('211', '67', '34', '15', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('212', '67', '35', '14', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('213', '67', '44', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('214', '67', '45', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('215', '67', '46', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('216', '67', '47', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('217', '67', '48', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('218', '67', '49', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('219', '67', '51', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('220', '67', '52', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('221', '67', '53', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('222', '67', '54', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('243', '71', '71', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('244', '71', '72', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('245', '71', '73', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('246', '71', '87', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('247', '71', '88', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('248', '71', '89', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('249', '71', '90', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('250', '71', '91', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('251', '71', '93', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('252', '71', '94', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('253', '71', '64', '15', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('254', '71', '65', '14', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('255', '71', '66', '15', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('256', '71', '69', '14', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('257', '71', '70', '16', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('258', '71', '75', '17', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('259', '71', '77', '16', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('260', '71', '78', '15', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('261', '71', '79', '15', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('262', '71', '80', '16', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('263', '73', '64', '16', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('264', '73', '65', '16', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('265', '73', '66', '15', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('266', '73', '69', '16', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('267', '73', '70', '16', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('268', '73', '75', '15', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('269', '73', '77', '17', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('270', '73', '78', '16', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('271', '73', '80', '16', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('272', '73', '81', '14', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('273', '73', '71', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('274', '73', '72', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('275', '73', '73', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('276', '73', '87', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('277', '73', '88', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('278', '73', '89', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('279', '73', '90', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('280', '73', '91', '21', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('281', '73', '92', '20', '0');
INSERT INTO `stu_exam_ques_result` VALUES ('282', '73', '93', '21', '0');

-- ----------------------------
-- Table structure for `subject`
-- ----------------------------
DROP TABLE IF EXISTS `subject`;
CREATE TABLE `subject` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subjectName` varchar(255) NOT NULL COMMENT '科目名',
  `content` varchar(255) DEFAULT NULL COMMENT '描述',
  `version` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `subjectName` (`subjectName`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of subject
-- ----------------------------
INSERT INTO `subject` VALUES ('1', '操作系统', '必修', '0');
INSERT INTO `subject` VALUES ('2', 'C语言', '必修', '0');

-- ----------------------------
-- Table structure for `user`
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userName` varchar(255) NOT NULL COMMENT '用户名',
  `passWord` varchar(255) NOT NULL COMMENT '密码',
  `statusId` int(11) NOT NULL COMMENT '用户状态',
  `typeId` int(11) NOT NULL COMMENT '用户类型',
  `version` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `userName` (`userName`),
  UNIQUE KEY `userName_2` (`userName`),
  KEY `userstatus_fk_1` (`statusId`),
  KEY `usertype_fk_2` (`typeId`),
  CONSTRAINT `userstatus_fk_1` FOREIGN KEY (`statusId`) REFERENCES `dict` (`id`),
  CONSTRAINT `usertype_fk_2` FOREIGN KEY (`typeId`) REFERENCES `dict` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', '1601061526', 'C4CA4238A0B923820DCC509A6F75849B', '1', '4', '0');
INSERT INTO `user` VALUES ('2', '1000', 'C4CA4238A0B923820DCC509A6F75849B', '1', '3', '0');
INSERT INTO `user` VALUES ('3', '1233', '111', '1', '3', '0');
INSERT INTO `user` VALUES ('11', '1908', 'C4CA4238A0B923820DCC509A6F75849B', '1', '5', '0');
INSERT INTO `user` VALUES ('13', '10001', '1', '1', '3', '0');
INSERT INTO `user` VALUES ('14', '12334', '4124', '1', '3', '0');
INSERT INTO `user` VALUES ('15', '2142142', '1221', '1', '3', '0');
INSERT INTO `user` VALUES ('16', '10002', 'C4CA4238A0B923820DCC509A6F75849B', '1', '4', '0');
INSERT INTO `user` VALUES ('17', '1601061521', '7C5D249A0D28569B7DF28F63EDD9D0B1', '1', '4', '0');
INSERT INTO `user` VALUES ('18', '1601061522', '28526503CA9C8A69BFDA8294081EE561', '1', '4', '0');
INSERT INTO `user` VALUES ('19', '1601061527', '15723AA04BB3219A1E2EAA554AA5D6C2', '1', '4', '0');
INSERT INTO `user` VALUES ('20', '1601061501', '35B279A15BB6909C4536FA9F868F5A97', '1', '4', '0');
INSERT INTO `user` VALUES ('21', '1601061530', '33CB9280D170E85FECAAFA46FD41ED7F', '1', '4', '0');
INSERT INTO `user` VALUES ('22', '1601061508', '8CF600AD0ABC9D0749355F2B583EB5F4', '1', '4', '0');
INSERT INTO `user` VALUES ('23', '1601061520', '4B26B8CC92DEBB9F611DA5F1EFB4C855', '1', '4', '0');
