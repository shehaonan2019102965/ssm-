package com.sk.commons;

import org.springframework.stereotype.Component;

import com.sk.dto.UserDto;
import com.sk.entity.User;


@Component
public class CopyDtoToEntity {
		
		public static User copyUserDtoToEntity(UserDto dto){
			User user = null;
			if(dto != null){
				user = new User();
				user.setId(dto.getId());
				user.setUsername(dto.getUsername());
				user.setPassword(dto.getPassword());
				user.setTypeid(dto.getTypeid());
				user.setStatusid(dto.getStatusid());
				user.setVersion(dto.getVersion());
			}
			return user;
		}

}
