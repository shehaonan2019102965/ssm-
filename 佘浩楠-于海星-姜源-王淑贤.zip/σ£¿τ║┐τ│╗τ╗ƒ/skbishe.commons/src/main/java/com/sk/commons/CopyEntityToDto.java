package com.sk.commons;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sk.dao.DictMapper;
import com.sk.dao.ExamMapper;
import com.sk.dao.ExamQuestionMapper;
import com.sk.dao.QuestionsMapper;
import com.sk.dao.SelectedMapper;
import com.sk.dao.StuExamQuesResultMapper;
import com.sk.dto.ExamDto;
import com.sk.dto.QuestionsDto;
import com.sk.dto.SelectedDto;
import com.sk.dto.StuExamDto;
import com.sk.dto.UserDto;
import com.sk.entity.Dict;
import com.sk.entity.Exam;
import com.sk.entity.ExamQuestion;
import com.sk.entity.Questions;
import com.sk.entity.Selected;
import com.sk.entity.StuExam;
import com.sk.entity.StuExamQuesResult;
import com.sk.entity.User;

@Component
public class CopyEntityToDto {
	
	@Autowired
	private  DictMapper dictMapper;
	@Autowired 
	private SelectedMapper selectedMapper;
	@Autowired
	private ExamQuestionMapper examQuestionMapper;
	@Autowired
	private ExamMapper examMapper;
	@Autowired
	private QuestionsMapper questionsMapper;
	@Autowired
	private StuExamQuesResultMapper examQuesResultMapper;
	
	public StuExamDto copyStuExamToDto(StuExam stuExam){
		StuExamDto dto = null;
		if(stuExam!=null){
			dto = new StuExamDto();
			dto.setId(stuExam.getId());
			dto.setScore(stuExam.getScore());
			dto.setStuid(stuExam.getStuid());
			dto.setContent(examMapper.selectByPrimaryKey(stuExam.getExamid()).getContent());
			HashMap<Integer,Integer> seqrMap = new HashMap<>();
			List<StuExamQuesResult> seqrList = examQuesResultMapper.selectByStuExamId(stuExam.getId());
			for(StuExamQuesResult seqr : seqrList){
				seqrMap.put(seqr.getExamQuesid(), seqr.getResultid());
			}
			List<ExamQuestion> eqList = 
					examQuestionMapper.getExamQuesByExamId(stuExam.getExamid());//试题及其问题
			List<QuestionsDto> quesDtoList = new ArrayList<>();
			for(ExamQuestion eq : eqList){
				QuestionsDto qDto = copyQuesEntityToDto(questionsMapper.selectByPrimaryKey(eq.getQuestid()));
				qDto.setJieguo(seqrMap.get(eq.getQuestid()));
				quesDtoList.add(qDto);
			}
			dto.setQuesDtoList(quesDtoList);
		}
		return dto;
	}
	
	public ExamDto copyExamEntityToDto(Exam exam){
		ExamDto dto = null;
		if(exam!=null){
			dto = new ExamDto();
			dto.setId(exam.getId());
			dto.setContent(exam.getContent());
			dto.setExamstatusid(exam.getExamstatusid());
			dto.setExamtime(exam.getExamtime());
			dto.setSubjectid(exam.getSubjectid());
			dto.setVersion(exam.getVersion());
			dto.setQuestionsList(examQuestionMapper.getExamQuesByExamId(exam.getId()));
		}
		return dto;
	}
	
	public QuestionsDto copyQuesEntityToDto(Questions ques){
		QuestionsDto dto = null;
		if(ques!=null){
			dto = new QuestionsDto();
			dto.setId(ques.getId());
			dto.setContent(ques.getContent());
			dto.setQtypeid(ques.getQtypeid());
			dto.setSubjectid(ques.getSubjectid());
			dto.setResult(ques.getResult());
			dto.setSelecteds(formatSelect(selectedMapper.getSelectedByQid(ques.getId())));
			dto.setVersion(ques.getVersion());
		}
		return dto;
	}
	
	private List<SelectedDto> formatSelect(List<Selected> list){
		List<SelectedDto> dtoList = null;
		if(list!=null){
			List<Dict> dicts = dictMapper.selectDictsByType(ExamConstant.QUES_SELECT_TYPE);
			HashMap<Integer, String> dictMap = new HashMap<>();
			for(Dict d:dicts){
				dictMap.put(d.getId(), d.getContent());
			}
			dtoList = new ArrayList<>();
			for(Selected s:list){
				SelectedDto dto = new SelectedDto();
				dto.setId(s.getId());
				dto.setContent(s.getContent());
				dto.setQid(s.getQid());
				dto.setSid(s.getSid());
				dto.setVersion(s.getVersion());
				dto.setSelect(dictMap.get(s.getSid()));
				dtoList.add(dto);
			}
		}
		return dtoList;
	}
	
	public UserDto copyUserEntityToDto(User user){
		UserDto dto = null;
		if(user != null){
			dto = new UserDto();
			dto.setId(user.getId());
			dto.setUsername(user.getUsername());
			dto.setPassword(user.getPassword());
			dto.setStatusid(user.getStatusid());
			dto.setStatus(dictMapper.selectByPrimaryKey(user.getStatusid()).getContent());
			dto.setTypeid(user.getTypeid());
			dto.setType(dictMapper.selectByPrimaryKey(user.getTypeid()).getContent());
			dto.setVersion(user.getVersion());
		}
		return dto;
	}
	
}
