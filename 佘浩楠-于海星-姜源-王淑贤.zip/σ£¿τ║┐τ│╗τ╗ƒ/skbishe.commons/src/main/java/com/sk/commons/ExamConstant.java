package com.sk.commons;

public class ExamConstant {

	
	//判断TYPE
	public static String QUES_JUDGE_TYPE = "question_judge";
	//判断CODE
	public static String QUES_T = "T";
	public static String QUES_F = "F";
	
	//选择TYPE
	public static String QUES_SELECT_TYPE = "question_selected";
	//选择CODE
	public static String QUES_A = "a";
	public static String QUES_B = "b";
	public static String QUES_C = "c";
	public static String QUES_D = "d";
	
	//题型TYPE
	public static String QUES_TYPE = "question_type";
	//题型CODE
	public static String QUES_SELECT = "select";
	public static String QUES_JUDGE = "judge";
	
	//验证码
	public static String CODE = "";
	
	//登陆结果TYPE
	public static String LOGIN_RES_TYPE = "login_result";
	//登陆结果CODE
	public static String LOGIN_RES_SUCCESS  = "success";
	public static String LOGIN_RES_FAIL = "fail";
	
	//用户账号状态TYPE
	public static String USER_STATUS_TYPE = "userstatus";
	//用户账号状态CODE
	public static String USER_STATUS_AVAILABLE = "available";
	public static String USER_STATUS_DISABLE = "disable";
	
	//用户类型TYPE
	public static String USERTYPE_TYPE = "usertype";
	//用户类型CODE
	public static String USERTYPE_ADMIN = "admin";
	public static String USERTYPE_TEACH = "teacher";
	public static String USERTYPE_STU = "student";
	
	//性别TYPE
	public static String USER_SEX = "sex";
	//性别CODE
	public static String USER_MEN = "men";
	public static String USER_WOMEN = "women";
	
	//试卷状态TYPE
	public static String EXAM_STATUS = "exam_status";
	//试卷状态CODE
	public static String EXAM_STATUS_OPEN = "open";
	public static String EXAM_STATUS_CLOSE = "close";
	public static String EXAM_STATUS_NOQUESTION = "noquestion";
	
	
	
}
