package com.sk.commons.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.sk.entity.StuExam;

public class SortStuExamUtil {
 
	/**
	 * 根据试卷ID分类成绩
	 * @param all
	 * @return
	 */
	public static HashMap<Integer, List<StuExam>> sortStuExamGroupByExamId(List<StuExam> all){
		HashMap<Integer, List<StuExam>> stuExamMap = null;
		if(all!=null&all.size()>0){
			stuExamMap = new HashMap<>();
			for (StuExam stuExam : all) {
				if(stuExamMap.containsKey(stuExam.getExamid())){
					stuExamMap.get(stuExam.getExamid()).add(stuExam);
				}else{
					List<StuExam> list = new ArrayList<>();
					list.add(stuExam);
					stuExamMap.put(stuExam.getExamid(), list);
				}
			}
			
		}
		
		return stuExamMap;
		
	}
}
