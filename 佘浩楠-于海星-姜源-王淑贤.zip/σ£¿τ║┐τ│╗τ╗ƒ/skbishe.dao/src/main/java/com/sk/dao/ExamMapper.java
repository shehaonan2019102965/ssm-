package com.sk.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sk.entity.Exam;

public interface ExamMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(Exam record);

    int insertSelective(Exam record);

    Exam selectByPrimaryKey(Integer id);
    
    Exam selectByName(@Param("name")String name);
    
    List<Exam> selectAllExam();

    List<Exam> selectByStatus(@Param("statusId")Integer statusId);
    
    int updateByPrimaryKeySelective(Exam record);

    int updateByPrimaryKey(Exam record);
    
    int updateExamStatus(Exam exam);
}