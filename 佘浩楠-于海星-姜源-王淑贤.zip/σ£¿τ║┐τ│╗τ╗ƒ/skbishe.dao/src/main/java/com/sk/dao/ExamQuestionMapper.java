package com.sk.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sk.entity.ExamQuestion;

public interface ExamQuestionMapper {
    int deleteByPrimaryKey(Integer id);
    
    int deleteByExamId(@Param("eId")Integer eId);

    int insert(ExamQuestion record);

    int insertSelective(ExamQuestion record);

    ExamQuestion selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(ExamQuestion record);

    int updateByPrimaryKey(ExamQuestion record);
    
    List<ExamQuestion> getExamQuesByExamId(@Param("eId")Integer eId);
}