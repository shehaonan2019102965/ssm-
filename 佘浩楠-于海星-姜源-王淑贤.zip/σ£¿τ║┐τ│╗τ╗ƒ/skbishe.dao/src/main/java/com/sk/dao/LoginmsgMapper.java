package com.sk.dao;

import com.sk.entity.Loginmsg;

public interface LoginmsgMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(Loginmsg record);

    int insertSelective(Loginmsg record);

    Loginmsg selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(Loginmsg record);

    int updateByPrimaryKey(Loginmsg record);
}