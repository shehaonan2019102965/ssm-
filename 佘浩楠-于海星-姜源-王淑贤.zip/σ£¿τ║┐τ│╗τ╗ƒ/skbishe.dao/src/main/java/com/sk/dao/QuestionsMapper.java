package com.sk.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sk.entity.Questions;

public interface QuestionsMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(Questions record);

    int insertSelective(Questions record);

    Questions selectByPrimaryKey(Integer id);
    
    List<Questions> selectAllQuestion();
    
    List<Questions> selectBySid(@Param("sid")Integer sid);

    int updateByPrimaryKeySelective(Questions record);

    int updateByPrimaryKey(Questions record);
    
    Questions selectByContent(@Param("content")String content);
    
    Questions selectByContentAndId(@Param("content")String content,@Param("id")Integer id);
}