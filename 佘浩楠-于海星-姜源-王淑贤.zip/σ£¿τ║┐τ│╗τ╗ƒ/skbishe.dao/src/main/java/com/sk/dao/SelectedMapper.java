package com.sk.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sk.entity.Selected;

public interface SelectedMapper {
    int deleteByPrimaryKey(Integer id);

    int deleteByQid(@Param("qid")Integer qid);
    
    int insert(Selected record);

    int insertSelective(Selected record);

    Selected selectByPrimaryKey(Integer id);
    
    List<Selected>getSelectedByQid(Integer id);
    
    int updateByPrimaryKeySelective(Selected record);

    int updateByPrimaryKey(Selected record);
}