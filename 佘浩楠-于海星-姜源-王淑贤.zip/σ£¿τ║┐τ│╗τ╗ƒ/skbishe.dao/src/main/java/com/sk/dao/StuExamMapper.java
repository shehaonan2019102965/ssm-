package com.sk.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sk.entity.StuExam;

public interface StuExamMapper {
    int deleteByPrimaryKey(Integer id);
    
    int deleteByStuNo(@Param("stuId")Integer stuId);
    
    int insert(StuExam record);

    int insertSelective(StuExam record);

    StuExam selectByPrimaryKey(Integer id);
    
    StuExam selectBySidAndExamId(@Param("sid")Integer sid,@Param("examId")Integer examId);

    int updateByPrimaryKeySelective(StuExam record);

    int updateByPrimaryKey(StuExam record);
    
    int updateStatus(StuExam stuExam);
    
    List<StuExam> getAllStuExams();
    
    List<StuExam> getStuExamsBySid(@Param("sid")Integer sid);
    
    List<StuExam> getStuExamByExamId(@Param("eid")Integer eid);
    
    List<StuExam> getStuExamHaveScore();
    
    int updateStuExamScore(StuExam stuExam);
}