package com.sk.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sk.entity.StuExamQuesResult;

public interface StuExamQuesResultMapper {
    int deleteByPrimaryKey(Integer id);

    int deleteByEid(@Param("eid")Integer eId);
    
    int insert(StuExamQuesResult record);

    int insertSelective(StuExamQuesResult record);

    StuExamQuesResult selectByPrimaryKey(Integer id);
    
    List<StuExamQuesResult> selectByStuExamId(@Param("stuExamId")Integer stuExamId);

    int updateByPrimaryKeySelective(StuExamQuesResult record);

    int updateByPrimaryKey(StuExamQuesResult record);
}