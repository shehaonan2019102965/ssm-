package com.sk.dao;

import java.util.List;

import com.sk.entity.Student;

public interface StudentMapper {
    int deleteByPrimaryKey(String studentno);

    int insert(Student record);

    int insertSelective(Student record);

    Student selectByPrimaryKey(String studentno);

    List<Student> selectAll();
    
    int updateByPrimaryKeySelective(Student record);

    int updateByPrimaryKey(Student record);
}