package com.sk.dao;

import java.util.List;



import org.apache.ibatis.annotations.Param;

import com.sk.entity.User;

public interface UserMapper {
    
	int deleteByPrimaryKey(Integer id);

    int insert(User record);

    int insertSelective(User record);

    User selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(User record);

    int updateByPrimaryKey(User user);
    
    int updateUserPWD(@Param("user")User user,@Param("nPwd")String nPwd);
    
    User login(User user);
    
    List<User> findAllUsers();
    
    User selectByName(@Param("name")String name);
}