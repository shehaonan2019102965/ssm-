package com.sk.dto;

import java.util.List;

import com.sk.entity.ExamQuestion;


public class ExamDto {
    private Integer id;

    private Integer subjectid;

    private Integer examtime;

    private Integer examstatusid;

    private String content;

    private Integer version;
    
    private Integer kaoshi;
    
    private List<ExamQuestion> questionsList;
    
    private List<QuestionsDto> quesDtoList;
    
    public Integer getKaoshi() {
		return kaoshi;
	}

	public void setKaoshi(Integer kaoshi) {
		this.kaoshi = kaoshi;
	}

	public List<ExamQuestion> getQuestionsList() {
		return questionsList;
	}

	public void setQuestionsList(List<ExamQuestion> questionsList) {
		this.questionsList = questionsList;
	}

	public List<QuestionsDto> getQuesDtoList() {
		return quesDtoList;
	}

	public void setQuesDtoList(List<QuestionsDto> quesDtoList) {
		this.quesDtoList = quesDtoList;
	}

	public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getSubjectid() {
        return subjectid;
    }

    public void setSubjectid(Integer subjectid) {
        this.subjectid = subjectid;
    }

    public Integer getExamtime() {
        return examtime;
    }

    public void setExamtime(Integer examtime) {
        this.examtime = examtime;
    }

    public Integer getExamstatusid() {
        return examstatusid;
    }

    public void setExamstatusid(Integer examstatusid) {
        this.examstatusid = examstatusid;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content == null ? null : content.trim();
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }
}