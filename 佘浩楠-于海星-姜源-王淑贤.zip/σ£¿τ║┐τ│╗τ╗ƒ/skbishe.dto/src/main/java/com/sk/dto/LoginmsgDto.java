package com.sk.dto;

import java.util.Date;

public class LoginmsgDto {
    private Integer id;

    private Integer userid;

    private String userip;

    private Date logintime;

    private Integer loginstatusid;

    private Integer version;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserid() {
        return userid;
    }

    public void setUserid(Integer userid) {
        this.userid = userid;
    }

    public String getUserip() {
        return userip;
    }

    public void setUserip(String userip) {
        this.userip = userip == null ? null : userip.trim();
    }

    public Date getLogintime() {
        return logintime;
    }

    public void setLogintime(Date logintime) {
        this.logintime = logintime;
    }

    public Integer getLoginstatusid() {
        return loginstatusid;
    }

    public void setLoginstatusid(Integer loginstatusid) {
        this.loginstatusid = loginstatusid;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }
}