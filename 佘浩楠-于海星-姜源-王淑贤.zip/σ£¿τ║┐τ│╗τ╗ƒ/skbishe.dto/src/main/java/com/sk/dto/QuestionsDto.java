package com.sk.dto;

import java.util.List;


public class QuestionsDto {
    private Integer id;

    private String content;

    private Integer qtypeid;

    private String type;
    
    private Integer subjectid;
    
    private Integer result;

    private Integer version;

    private Integer xuanze;
    
    private List<SelectedDto> selecteds;
    
    private Integer jieguo;//具体选的
    
    public Integer getJieguo() {
		return jieguo;
	}

	public void setJieguo(Integer jieguo) {
		this.jieguo = jieguo;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Integer getXuanze() {
		return xuanze;
	}

	public void setXuanze(Integer xuanze) {
		this.xuanze = xuanze;
	}

    public List<SelectedDto> getSelecteds() {
		return selecteds;
	}

	public void setSelecteds(List<SelectedDto> selecteds) {
		this.selecteds = selecteds;
	}

	public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content == null ? null : content.trim();
    }

    public Integer getQtypeid() {
        return qtypeid;
    }

    public void setQtypeid(Integer qtypeid) {
        this.qtypeid = qtypeid;
    }

    public Integer getResult() {
        return result;
    }

    public void setResult(Integer result) {
        this.result = result;
    }

    public Integer getSubjectid() {
		return subjectid;
	}

	public void setSubjectid(Integer subjectid) {
		this.subjectid = subjectid;
	}

	public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }
}