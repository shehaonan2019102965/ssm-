package com.sk.dto;

/**
 * 用于成绩统计及展示
 * @author thf
 *
 */
public class ScoreDto {

	private String examContent;
	private Integer examId;
	private Float avgScore;
	private Integer maxScore;
	private Integer minScore;
	private Integer subject;
	private Integer renshu;
	public Integer getRenshu() {
		return renshu;
	}
	public void setRenshu(Integer renshu) {
		this.renshu = renshu;
	}
	public String getExamContent() {
		return examContent;
	}
	public void setExamContent(String examContent) {
		this.examContent = examContent;
	}
	public Integer getExamId() {
		return examId;
	}
	public void setExamId(Integer examId) {
		this.examId = examId;
	}
	public Float getAvgScore() {
		return avgScore;
	}
	public void setAvgScore(Float avgScore) {
		this.avgScore = avgScore;
	}
	public Integer getMaxScore() {
		return maxScore;
	}
	public void setMaxScore(Integer maxScore) {
		this.maxScore = maxScore;
	}
	public Integer getMinScore() {
		return minScore;
	}
	public void setMinScore(Integer minScore) {
		this.minScore = minScore;
	}
	public Integer getSubject() {
		return subject;
	}
	public void setSubject(Integer subject) {
		this.subject = subject;
	}
	
	
}
