package com.sk.dto;

public class SelectedDto {
    private Integer id;

    private Integer qid;

    private Integer sid;
    
    private String select;

    private String content;

    private String imageurl;

    private Integer version;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getQid() {
        return qid;
    }

    public void setQid(Integer qid) {
        this.qid = qid;
    }

    public Integer getSid() {
        return sid;
    }

    public void setSid(Integer sid) {
        this.sid = sid;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content == null ? null : content.trim();
    }

    public String getImageurl() {
        return imageurl;
    }

    public void setImageurl(String imageurl) {
        this.imageurl = imageurl == null ? null : imageurl.trim();
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

	public String getSelect() {
		return select;
	}

	public void setSelect(String select) {
		this.select = select;
	}

	public SelectedDto(Integer id, Integer qid, Integer sid, String select,
			String content, String imageurl, Integer version) {
		this.id = id;
		this.qid = qid;
		this.sid = sid;
		this.select = select;
		this.content = content;
		this.imageurl = imageurl;
		this.version = version;
	}
    
	public SelectedDto(Integer qid, Integer sid, String select,
			String content, String imageurl, Integer version) {
		this.qid = qid;
		this.sid = sid;
		this.select = select;
		this.content = content;
		this.imageurl = imageurl;
		this.version = version;
	}
	
	public SelectedDto() {

	}
	
	public SelectedDto(Integer sid, String content, Integer version) {
		this.sid = sid;
		this.content = content;
		this.version = version;
	}
	public SelectedDto(Integer id, Integer qid, Integer sid, String content,
			Integer version) {
		this.id = id;
		this.qid = qid;
		this.sid = sid;
		this.content = content;
		this.version = version;
	}
	
	
}