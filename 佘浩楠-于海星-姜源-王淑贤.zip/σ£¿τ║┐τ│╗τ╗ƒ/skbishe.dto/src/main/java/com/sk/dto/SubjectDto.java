package com.sk.dto;

public class SubjectDto {
    private Integer id;

    private String subjectname;

    private Integer stypeid;

    private Integer version;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSubjectname() {
        return subjectname;
    }

    public void setSubjectname(String subjectname) {
        this.subjectname = subjectname == null ? null : subjectname.trim();
    }

    public Integer getStypeid() {
        return stypeid;
    }

    public void setStypeid(Integer stypeid) {
        this.stypeid = stypeid;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }
}