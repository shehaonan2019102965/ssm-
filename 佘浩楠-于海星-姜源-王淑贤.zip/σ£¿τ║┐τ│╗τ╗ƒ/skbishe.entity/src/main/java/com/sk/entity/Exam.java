package com.sk.entity;

public class Exam {
    private Integer id;

    private Integer subjectid;

    private Integer examtime;

    private Integer examstatusid;

    private String content;

    private Integer version;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getSubjectid() {
        return subjectid;
    }

    public void setSubjectid(Integer subjectid) {
        this.subjectid = subjectid;
    }

    public Integer getExamtime() {
        return examtime;
    }

    public void setExamtime(Integer examtime) {
        this.examtime = examtime;
    }

    public Integer getExamstatusid() {
        return examstatusid;
    }

    public void setExamstatusid(Integer examstatusid) {
        this.examstatusid = examstatusid;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content == null ? null : content.trim();
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }
}