package com.sk.entity;

public class ExamQuestion {
    private Integer id;

    private Integer examid;

    private Integer questid;

    private Integer version;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getExamid() {
        return examid;
    }

    public void setExamid(Integer examid) {
        this.examid = examid;
    }

    public Integer getQuestid() {
        return questid;
    }

    public void setQuestid(Integer questid) {
        this.questid = questid;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }
}