package com.sk.entity;

public class Selected {
    private Integer id;

    private Integer qid;

    private Integer sid;

    private String content;

    private Integer version;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getQid() {
        return qid;
    }

    public void setQid(Integer qid) {
        this.qid = qid;
    }

    public Integer getSid() {
        return sid;
    }

    public void setSid(Integer sid) {
        this.sid = sid;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content == null ? null : content.trim();
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

	public Selected(Integer id, Integer qid, Integer sid, String content,
			Integer version) {
		this.id = id;
		this.qid = qid;
		this.sid = sid;
		this.content = content;
		this.version = version;
	}
	public Selected() {
		
	}
    
	public Selected(Integer sid, String content, Integer version) {
		this.sid = sid;
		this.content = content;
		this.version = version;
	}
	
}