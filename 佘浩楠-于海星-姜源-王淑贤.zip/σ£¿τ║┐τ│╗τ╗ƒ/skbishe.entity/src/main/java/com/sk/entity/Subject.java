package com.sk.entity;

public class Subject {
    private Integer id;

    private String subjectname;

    private String content;

    private Integer version;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSubjectname() {
        return subjectname;
    }

    public void setSubjectname(String subjectname) {
        this.subjectname = (subjectname == null||"".equals(subjectname)) ? null : subjectname.trim();
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = (content == null || "".equals(content)) ? null : content.trim();
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }
}