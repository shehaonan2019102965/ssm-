package com.sk.service;


import java.util.List;

import com.sk.entity.Dict;


public interface DictService {

	Dict getDictByTypeAndCode(String dictType,String dictCode); 
	List<Dict> getDictByType(String type);
}
