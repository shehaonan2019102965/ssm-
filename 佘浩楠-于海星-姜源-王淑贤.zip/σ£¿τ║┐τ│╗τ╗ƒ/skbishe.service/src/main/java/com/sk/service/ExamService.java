package com.sk.service;

import java.util.List;

import com.sk.entity.Exam;

public interface ExamService {
	
	List<Exam> getAllExams();
	
	List<Exam> getExamsByStatus(Integer statusId);
	
	Exam getExamByName(String name);

	boolean insertExam(Exam exam);
	
	boolean updateExamStatus(Exam exam);
	
	Exam getExamById(Integer id);
	
	boolean editExam(Integer qIds[],Integer id,Integer version);
}

