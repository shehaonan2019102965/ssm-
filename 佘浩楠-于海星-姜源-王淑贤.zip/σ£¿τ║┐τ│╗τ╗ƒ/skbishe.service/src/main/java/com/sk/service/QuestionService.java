package com.sk.service;

import java.util.List;

import com.sk.dto.QuestionsDto;
import com.sk.entity.Questions;

public interface QuestionService {

	List<Questions> getAllQuestions();
	
	List<Questions> getQuestionsBySid(Integer sid);
	
	boolean delQuestionById(Integer id, Integer tid);
	
	boolean addQuestion(QuestionsDto dto);
	
	Questions getQuestionByContent(String content);
	
	Questions getQuestionByContentAndId(String content,Integer id);
	
	Questions getQuestionById(Integer id);
	
	boolean updateQuestionById(QuestionsDto dto);
}
