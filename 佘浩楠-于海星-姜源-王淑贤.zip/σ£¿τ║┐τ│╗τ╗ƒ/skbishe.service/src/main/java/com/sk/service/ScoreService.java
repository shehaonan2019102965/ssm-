package com.sk.service;

import java.util.List;

import com.sk.dto.ScoreDto;

public interface ScoreService {

	List<ScoreDto> getScoreForStu(String stuNo);
	
	List<ScoreDto> getScoreForTeach();
	
	List<ScoreDto> getScoreForAdmin();
}
