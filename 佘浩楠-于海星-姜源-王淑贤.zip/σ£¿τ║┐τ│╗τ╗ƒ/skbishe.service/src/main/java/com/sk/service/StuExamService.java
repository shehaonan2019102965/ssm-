package com.sk.service;

import java.util.List;

import com.sk.dto.StuExamDto;
import com.sk.entity.StuExam;

public interface StuExamService {

	List<StuExam> getStuExamsByStuId(Integer stuId);
	
	int addStuExam(StuExam stuExam);
	
	StuExam getStuExamById(Integer id);
	
	boolean addStuExam(StuExam stuExam,String[] qAndSids);
	
	StuExam getStuExamBySidAndExamId(Integer sId,Integer examId);
	
	List<StuExamDto> getStuExamByExamId(Integer eid);
	
	boolean updateStuExamScore(StuExam stuExam);
	
}
