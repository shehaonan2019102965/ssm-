package com.sk.service;

import java.util.List;

import com.sk.entity.Student;

public interface StudentService {

	List<Student> getAllStudents();
	
	boolean delStu(String no);
	
	boolean addStu(Student student);
	
	Student getStudentByNo(String no);
}
