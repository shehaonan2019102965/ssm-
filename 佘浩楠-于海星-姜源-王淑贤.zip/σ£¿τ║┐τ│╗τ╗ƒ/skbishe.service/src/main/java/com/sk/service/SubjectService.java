package com.sk.service;

import java.util.List;
import com.sk.entity.Subject;


public interface SubjectService {

	List<Subject> getAllSubjects();
	
	boolean delSubjectById(Integer id);
	
	Subject getSubjectById(Integer id);
	
	boolean updateSubject(Subject sub);
	
	boolean addSubject(Subject sub);
	
	Subject getSubjectByName(String name);
}
