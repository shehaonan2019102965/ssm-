package com.sk.service;

import java.util.List;

import com.sk.dto.UserDto;
import com.sk.entity.Loginmsg;
import com.sk.entity.User;

public interface UserService {

	User login(UserDto dto); 
	
	int addLoginMsg(Loginmsg msg);
	
	List<User> getAllUser();
	
	boolean delUserById(Integer userId);
	
	User getUserById(Integer id);
	
	boolean updateUser(User user);
	
	boolean updateUserPWD(User user,String nPwd);
	
	boolean addUser(User user);
	
	User getUserByName(String name);
}
