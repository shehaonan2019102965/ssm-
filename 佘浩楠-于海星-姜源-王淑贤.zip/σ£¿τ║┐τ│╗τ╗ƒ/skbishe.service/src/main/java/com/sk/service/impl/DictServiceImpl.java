package com.sk.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.sk.dao.DictMapper;
import com.sk.entity.Dict;
import com.sk.service.DictService;

@Service
public class DictServiceImpl implements DictService {

	@Resource
	private DictMapper dictMapper;
	
	@Override
	public Dict getDictByTypeAndCode(String dictType, String dictCode) {
		
		return dictMapper.selectDictByCodeAndType(dictCode, dictType);
	}

	@Override
	public List<Dict> getDictByType(String type) {
		return dictMapper.selectDictsByType(type);
	}

}
