package com.sk.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.sk.commons.ExamConstant;
import com.sk.dao.DictMapper;
import com.sk.dao.ExamMapper;
import com.sk.dao.ExamQuestionMapper;
import com.sk.entity.Exam;
import com.sk.entity.ExamQuestion;
import com.sk.service.ExamService;

@Service
public class ExamServiceImpl implements ExamService {

	@Resource
	private ExamMapper examMapper;
	@Resource
	private ExamQuestionMapper examQuestionMapper;
	@Resource
	private DictMapper dictMapper;
	
	@Override
	public List<Exam> getAllExams() {
		return examMapper.selectAllExam();
	}

	@Override
	public Exam getExamByName(String name) {
		return examMapper.selectByName(name);
	}

	@Override
	public boolean insertExam(Exam exam) {
		return examMapper.insert(exam)>0;
	}

	@Override
	public boolean updateExamStatus(Exam exam) {
		return examMapper.updateExamStatus(exam)>0;
	}

	@Override
	public Exam getExamById(Integer id) {
		return examMapper.selectByPrimaryKey(id);
	}

	@Override
	public boolean editExam(Integer[] qIds, Integer id,Integer version) {
		examQuestionMapper.deleteByExamId(id);
		Exam exam = new Exam();
		exam.setId(id);
		exam.setExamstatusid(dictMapper.selectDictByCodeAndType(ExamConstant.EXAM_STATUS_OPEN, ExamConstant.EXAM_STATUS).getId());
		exam.setVersion(version);
		if(!(examMapper.updateExamStatus(exam)>0)){
			return false;
		}
		for (Integer qid : qIds) {
			ExamQuestion eq = new ExamQuestion();
			eq.setExamid(id);
			eq.setQuestid(qid);
			eq.setVersion(0);
			if(examQuestionMapper.insert(eq)<1){
				return false;
			}
		}
		return true;
	}

	@Override
	public List<Exam> getExamsByStatus(Integer statusId) {
		return examMapper.selectByStatus(statusId);
	}

}
