package com.sk.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.sk.commons.ExamConstant;
import com.sk.dao.DictMapper;
import com.sk.dao.QuestionsMapper;
import com.sk.dao.SelectedMapper;
import com.sk.dto.QuestionsDto;
import com.sk.dto.SelectedDto;
import com.sk.entity.Dict;
import com.sk.entity.Questions;
import com.sk.entity.Selected;
import com.sk.service.QuestionService;

@Service
public class QuestionServiceImpl implements QuestionService {

	@Resource
	private QuestionsMapper questionsMapper;
	@Resource
	private SelectedMapper selectedMapper;
	@Resource
	private DictMapper dictMapper;
	
	@Override
	public List<Questions> getAllQuestions() {
		return questionsMapper.selectAllQuestion();
	}

	@Override
	public boolean delQuestionById(Integer id ,Integer tid) {
		if(questionsMapper.deleteByPrimaryKey(id)>0){
			if(tid.equals(dictMapper.selectDictByCodeAndType(ExamConstant.QUES_SELECT, ExamConstant.QUES_TYPE).getId())){
				if(selectedMapper.deleteByQid(id)>0){
					return true;
				}else{
					return false;
				}
			}else{
				return true;
			}
		}else{
			return false;
		}
		
	}

	@Override
	public boolean addQuestion(QuestionsDto dto) {
		Questions questions = new Questions();
		questions.setContent(dto.getContent());
		questions.setSubjectid(dto.getSubjectid());
		questions.setQtypeid(dto.getQtypeid());
		questions.setVersion(dto.getVersion());
		questions.setResult(dto.getResult());
		if(questionsMapper.insert(questions)>0){
			Dict dict = dictMapper.selectDictByCodeAndType(ExamConstant.QUES_SELECT,ExamConstant.QUES_TYPE);
			if(dict.getId().equals(dto.getQtypeid())){
				List<SelectedDto> sDtoList = dto.getSelecteds();
				List<Selected> sList = formatSelect(sDtoList);
				for(Selected s: sList){
					s.setQid(questions.getId());
					if(selectedMapper.insert(s)<1){
						return false;
					}
				}
			}
			return true;
		}else{
			return false;
		}
	}

	@Override
	public Questions getQuestionByContent(String content) {
		return questionsMapper.selectByContent(content);
	}

	@Override
	public Questions getQuestionById(Integer id) {
		return questionsMapper.selectByPrimaryKey(id);
	}

	@Override
	public boolean updateQuestionById(QuestionsDto dto) {
		Questions questions = new Questions();
		questions.setId(dto.getId());
		questions.setContent(dto.getContent());
		questions.setSubjectid(dto.getSubjectid());
		questions.setQtypeid(dto.getQtypeid());
		questions.setVersion(dto.getVersion());
		questions.setResult(dto.getResult());
		if(questionsMapper.updateByPrimaryKey(questions)>0){
			Dict dict = dictMapper.selectDictByCodeAndType(ExamConstant.QUES_SELECT,ExamConstant.QUES_TYPE);
			if(dict.getId().equals(dto.getQtypeid())){
				List<Selected> sList = formatSelect(dto.getSelecteds());
				for(Selected s: sList){
					s.setQid(questions.getId());
					if(selectedMapper.updateByPrimaryKey(s)<1){
						return false;
					}
				}
			}
			return true;
		}else{
			return false;
		}
	}

	@Override
	public Questions getQuestionByContentAndId(String content, Integer id) {
		return questionsMapper.selectByContentAndId(content,id);
	}

	@Override
	public List<Questions> getQuestionsBySid(Integer sid) {
		return questionsMapper.selectBySid(sid);
	}
	
	private List<Selected> formatSelect(List<SelectedDto> list){
		List<Selected> slist = null;
		if( list != null){
			slist = new ArrayList<>();
			for(SelectedDto dto: list){
				Selected s = new Selected();
				s.setId(dto.getId()!=null?dto.getId():null);
				s.setContent(dto.getContent()!=null?dto.getContent():null);
				s.setQid(dto.getQid()!=null?dto.getQid():null);
				s.setSid(dto.getSid()!=null?dto.getSid():null);
				s.setVersion(dto.getVersion()!=null?dto.getVersion():null);
				slist.add(s);
			}
		}
		return slist;
	}
}
