package com.sk.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.sk.commons.util.SortStuExamUtil;
import com.sk.dao.ExamMapper;
import com.sk.dao.StuExamMapper;
import com.sk.dto.ScoreDto;
import com.sk.entity.Exam;
import com.sk.entity.StuExam;
import com.sk.service.ScoreService;

@Service
public class ScoreServiceImpl implements ScoreService {

	@Resource
	private StuExamMapper stuExamMapper;
	@Resource
	private ExamMapper examMapper;
	
	
	@Override
	public List<ScoreDto> getScoreForStu(String stuNo) {
		
		return null;
	}

	@Override
	public List<ScoreDto> getScoreForTeach() {
		return formatStuExamForTeach(stuExamMapper.getStuExamHaveScore());
	}

	@Override
	public List<ScoreDto> getScoreForAdmin() {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * 格式化处理成绩for成绩管理
	 * @param scoreList
	 * @return
	 */
	private List<ScoreDto> formatStuExamForTeach(List<StuExam> scoreList){
		List<ScoreDto> dtoList = null;
		if(scoreList!=null && scoreList.size()>0){
			dtoList = new ArrayList<>();
			HashMap<Integer, List<StuExam>> stuExamMap = SortStuExamUtil.sortStuExamGroupByExamId(scoreList);
			for(Integer i : stuExamMap.keySet()){
				ScoreDto dto = new ScoreDto();
				Exam exam = examMapper.selectByPrimaryKey(i);
				dto.setExamId(i);
				dto.setExamContent(exam.getContent());
				dto.setSubject(exam.getSubjectid());
				dto = getAvgAndMaxAndMin(dto,stuExamMap.get(i));
				dtoList.add(dto);
			}
			
		}
		return dtoList;
	}
	
	/**
	 * 求考试成绩的平均分，最高，最低分
	 * @param dto
	 * @param list
	 * @return
	 */
	private ScoreDto getAvgAndMaxAndMin(ScoreDto dto,List<StuExam> list){
		if(list!=null && list.size()>0){
			float zongfen = 0;
			int max = list.get(0).getScore();
			int min = list.get(0).getScore();
			for(StuExam stu : list){
				zongfen += stu.getScore();
				if(stu.getScore()>max){
					max = stu.getScore();
				}
				if(stu.getScore()<min){
					min = stu.getScore();
				}
			}
			dto.setRenshu(list.size());
			dto.setMaxScore(max);
			dto.setMinScore(min);
			dto.setAvgScore(zongfen/list.size());
		}
		return dto;
	}
}
