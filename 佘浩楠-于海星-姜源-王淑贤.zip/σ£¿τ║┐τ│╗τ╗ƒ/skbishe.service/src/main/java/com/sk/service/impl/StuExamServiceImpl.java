package com.sk.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.sk.dao.StuExamMapper;
import com.sk.dao.StuExamQuesResultMapper;
import com.sk.dto.StuExamDto;
import com.sk.entity.Exam;
import com.sk.entity.StuExam;
import com.sk.entity.StuExamQuesResult;
import com.sk.service.ExamService;
import com.sk.service.StuExamService;

@Service
public class StuExamServiceImpl implements StuExamService {

	@Resource
	private StuExamMapper stuExamMapper;
	@Resource
	private StuExamQuesResultMapper stuExamQuesResultMapper;
	@Resource
	private ExamService examService;
	
	@Override
	public List<StuExam> getStuExamsByStuId(Integer stuId) {
		return stuExamMapper.getStuExamsBySid(stuId);
	}

	@Override
	public int addStuExam(StuExam stuExam) {
		if(stuExamMapper.insert(stuExam)>0){
			return stuExam.getId();
		}
		return -1;
	}

	@Override
	public StuExam getStuExamById(Integer id) {
		return stuExamMapper.selectByPrimaryKey(id);
	}

	@Override
	public boolean addStuExam(StuExam stuExam, String[] qAndSids) {
		if(stuExam==null||qAndSids==null||qAndSids.length==0){
			return false;
		}
		int score = 0;
		List<StuExamQuesResult> list = new ArrayList<>();
		for(String src : qAndSids){
			StuExamQuesResult seqr = new StuExamQuesResult();
			seqr.setStuExamid(stuExam.getId());
			seqr.setVersion(0);
			String[] s = src.split(";");
			seqr.setExamQuesid(Integer.parseInt(s[0]));
			seqr.setResultid(Integer.parseInt(s[1]));
			if(s[1].equals(s[2])){
				score += 5;
			}
			list.add(seqr);
		}
		stuExam.setScore(score);
		if(stuExamMapper.updateStatus(stuExam)<1){
			return false;
		}
		for(StuExamQuesResult result:list){
			if(stuExamQuesResultMapper.insert(result)<1){
				return false;
			}
		}
		
		return true;
	}

	@Override
	public StuExam getStuExamBySidAndExamId(Integer sid, Integer examId) {
		
		return stuExamMapper.selectBySidAndExamId(sid, examId);
	}

	@Override
	public List<StuExamDto> getStuExamByExamId(Integer eid) {
		List<StuExam> eList = stuExamMapper.getStuExamByExamId(eid);
		Exam exam = examService.getExamById(eid);
		List<StuExamDto> dtoList = null;
		if(eList!=null && eList.size()>0){
			dtoList = new ArrayList<>();
			for(StuExam stu : eList){
				StuExamDto sed = new StuExamDto();
				sed.setId(stu.getId());
				sed.setContent(exam.getContent());
				sed.setStuid(stu.getStuid());
				sed.setScore(stu.getScore());
				sed.setSubject(exam.getSubjectid());
				sed.setVersion(stu.getVersion());
				dtoList.add(sed);
			}
		}
		return dtoList;
	}

	@Override
	public boolean updateStuExamScore(StuExam stuExam) {
		return stuExamMapper.updateStuExamScore(stuExam)>0;
	}

	
}
