package com.sk.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.sk.commons.ExamConstant;
import com.sk.commons.util.MD5EncodingUtil;
import com.sk.dao.DictMapper;
import com.sk.dao.StuExamMapper;
import com.sk.dao.StuExamQuesResultMapper;
import com.sk.dao.StudentMapper;
import com.sk.dao.UserMapper;
import com.sk.entity.StuExam;
import com.sk.entity.Student;
import com.sk.entity.User;
import com.sk.service.StudentService;

@Service
public class StudentServiceImpl implements StudentService {

	@Resource
	private StudentMapper studentMapper;
	@Resource
	private UserMapper userMapper;
	@Resource
	private DictMapper dictMapper;
	@Resource
	private StuExamMapper stuExamMapper;
	@Resource
	private StuExamQuesResultMapper stuExamQuesResultMapper;
	
	@Override
	public List<Student> getAllStudents() {
		return studentMapper.selectAll();
	}

	@Override
	public boolean delStu(String no) {
		if(studentMapper.deleteByPrimaryKey(no)<1){
			return false;
		}
		if(userMapper.deleteByPrimaryKey(userMapper.selectByName(no).getId())<1){
			return false;
		}
		List<StuExam> seList = stuExamMapper.getStuExamsBySid(Integer.parseInt(no));
		if(seList!=null && seList.size()>0){
			for(StuExam se :seList){
				if(stuExamQuesResultMapper.deleteByEid(se.getExamid())<1){
					return false;
				}
			}
			if(stuExamMapper.deleteByStuNo(Integer.parseInt(no))<1){
				return false;
			}
		}
		return true;
	}

	@Override
	public boolean addStu(Student student) {
		if(studentMapper.insert(student)<1){
			return false;
		}
		User user = new User();
		user.setUsername(student.getStudentno());
		user.setStatusid(dictMapper.selectDictByCodeAndType(ExamConstant.USER_STATUS_AVAILABLE, ExamConstant.USER_STATUS_TYPE).getId());
		user.setTypeid(dictMapper.selectDictByCodeAndType(ExamConstant.USERTYPE_STU,ExamConstant.USERTYPE_TYPE).getId());
		user.setPassword(MD5EncodingUtil.getMD5(student.getStudentno()));
		user.setVersion(0);
		if(userMapper.insert(user)<1){
			return false;
		}
		return true;
	}

	@Override
	public Student getStudentByNo(String no) {
		return studentMapper.selectByPrimaryKey(no);
	}

}
