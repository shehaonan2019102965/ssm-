package com.sk.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.sk.dao.SubjectMapper;
import com.sk.entity.Subject;
import com.sk.service.SubjectService;

@Service
public class SubjectServiceImpl implements SubjectService {

	@Resource
	private SubjectMapper subjectMapper;
	
	@Override
	public List<Subject> getAllSubjects() {
		return subjectMapper.getAllSubjects();
	}

	@Override
	public boolean delSubjectById(Integer id) {
		return subjectMapper.deleteByPrimaryKey(id)>0;
	}

	@Override
	public Subject getSubjectById(Integer id) {
		return subjectMapper.selectByPrimaryKey(id);
	}

	@Override
	public boolean updateSubject(Subject sub) {
		return subjectMapper.updateByPrimaryKeySelective(sub)>0;
	}

	@Override
	public boolean addSubject(Subject sub) {
		return subjectMapper.insert(sub)>0;
	}

	@Override
	public Subject getSubjectByName(String name) {
		return subjectMapper.selectByName(name);
	}

}
