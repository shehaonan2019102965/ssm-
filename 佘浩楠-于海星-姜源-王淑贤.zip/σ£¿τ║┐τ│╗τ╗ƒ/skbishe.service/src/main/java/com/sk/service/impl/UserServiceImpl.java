package com.sk.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.sk.commons.CopyDtoToEntity;
import com.sk.dao.LoginmsgMapper;
import com.sk.dao.UserMapper;
import com.sk.dto.UserDto;
import com.sk.entity.Loginmsg;
import com.sk.entity.User;
import com.sk.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Resource
	private UserMapper userMapper;
	@Resource
	private LoginmsgMapper loginmsgMapper;
	
	@Override
	public User login(UserDto dto) {
		return userMapper.login(CopyDtoToEntity.copyUserDtoToEntity(dto));
	}

	@Override
	public int addLoginMsg(Loginmsg msg) {
		return loginmsgMapper.insert(msg);
	}

	@Override
	public List<User> getAllUser() {
		return userMapper.findAllUsers();
	}

	@Override
	public boolean delUserById(Integer userId) {
		return userMapper.deleteByPrimaryKey(userId)>0;
	}

	@Override
	public User getUserById(Integer id) {
		return userMapper.selectByPrimaryKey(id);
	}

	@Override
	public boolean updateUser(User user) {
		return userMapper.updateByPrimaryKey(user)>0;
	}

	@Override
	public boolean addUser(User user) {
		return userMapper.insert(user)>0;
	}

	@Override
	public User getUserByName(String name) {
		return userMapper.selectByName(name);
	}

	@Override
	public boolean updateUserPWD(User user,String nPwd) {
		return userMapper.updateUserPWD(user,nPwd)>0;
	}

}
