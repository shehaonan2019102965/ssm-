package com.sk.controller;

import java.io.File;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.sk.commons.util.MD5EncodingUtil;
import com.sk.entity.User;
import com.sk.service.UserService;

@RequestMapping("/util")
@Controller
public class TestController {
	
	@Autowired
	private UserService userService;
	
	private static final String TEST = "index";
//	@Resource
//	private EmpService empService; 
//	
	private static final Logger log = Logger.getLogger(TestController.class);
	
	@RequestMapping("/test")
	public String test(){
		
		return TEST;
	}
	
	@RequestMapping("/toUpdate")
	public String toUpdateUser(){
		return "userUpdate";
	}
	
	@ResponseBody
	@RequestMapping("/updatePwd")
	public String updatePwd(HttpServletRequest request){
		String name = request.getParameter("name");
		String pwd = request.getParameter("pwd");
		String nPwd = request.getParameter("nPwd");
		User user = new User();
		user.setUsername(name);
		user.setPassword(MD5EncodingUtil.getMD5(pwd));
		if(userService.updateUserPWD(user, MD5EncodingUtil.getMD5(nPwd))){
			return "0";
		}
		return "1";
	}
	
	//@ResponseBody
	@RequestMapping("/loginExamSystem")
	public String loginExamSys(){
		return TEST;
	}
	
	
	
	public String upFileTest(@RequestParam(value="file",required=false)MultipartFile file,HttpServletRequest request){
		file.getOriginalFilename();//传输的文件名
		String name = System.currentTimeMillis()+".png";
		String path = request.getSession().getServletContext().getRealPath("/static/imgs");
		File uploadFile = new File(path,name);
		if(!uploadFile.exists()){
			uploadFile.mkdirs();//新建
		}
		//复制图片
		try {
			file.transferTo(uploadFile);
		} catch (Exception e) {
			log.error(e);
		} 
		return null;
	}
}
