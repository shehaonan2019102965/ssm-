package com.sk.controller.admin;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sk.commons.CopyEntityToDto;
import com.sk.dto.QuestionsDto;
import com.sk.dto.UserDto;
import com.sk.entity.Exam;
import com.sk.entity.Questions;
import com.sk.entity.StuExam;
import com.sk.entity.Subject;
import com.sk.entity.User;
import com.sk.service.ExamService;
import com.sk.service.QuestionService;
import com.sk.service.ScoreService;
import com.sk.service.StuExamService;
import com.sk.service.SubjectService;
import com.sk.service.UserService;


@Controller
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	private UserService userService;
	@Autowired
	private CopyEntityToDto copyEntityToDto;
	@Autowired
	private SubjectService subjectService;
	@Autowired
	private ExamService examService;
	@Autowired
	private QuestionService questionService;
	@Autowired 
	private ScoreService scoreService;
	@Autowired
	private StuExamService stuExamService;
	
	/**
	 * 后台管理首页
	 * @return
	 */
	@RequestMapping("/index")
	public String  adminIndex(){
		return "_admin/index";
	}
	
	/**
	 * 成绩管理
	 * @return
	 */
	@RequestMapping("/score")
	public String scoreIndex(HttpServletRequest request){
		request.setAttribute("subList", subjectService.getAllSubjects());
		request.setAttribute("scoreList", scoreService.getScoreForTeach());
		return "_admin/score";
	}
	
	/**
	 * 题库管理
	 * @return
	 */
	@RequestMapping("/question")
	public String questionIndex(HttpServletRequest request){
		List<QuestionsDto> questDtoList = null;
		List<Questions> questList = questionService.getAllQuestions();
		if(questList != null&&questList.size()>0){
			questDtoList = new ArrayList<>();
			for(Questions q:questList){
				questDtoList.add(copyEntityToDto.copyQuesEntityToDto(q));
			}
		}
		request.setAttribute("subList", subjectService.getAllSubjects());
		request.setAttribute("questionList", questDtoList);
		return "_admin/question";
	}
	
	/**
	 * 科目管理界面
	 * @return
	 */
	@RequestMapping("/subject")
	public String subjectIndex(HttpServletRequest request){
		List<Subject> subjectList = subjectService.getAllSubjects();
		request.setAttribute("subjectList", subjectList);
		return "_admin/subject";
	}
	
	/**
	 * 试题管理首页
	 * @return
	 */
	@RequestMapping("/exam")
	public String examIndex(HttpServletRequest request){
		List<Exam> examList = examService.getAllExams();
		List<Subject> subList = subjectService.getAllSubjects();
		request.setAttribute("examList", examList);
		request.setAttribute("subList", subList);
		return "_admin/exam";
	}
	
	/**
	 * 用户管理首页
	 * @return
	 */
	@RequestMapping("/user")
	public String userIndex(HttpServletRequest request){
		List<UserDto> userDtoList = null;
		List<User> userList = userService.getAllUser();
		if(userList!=null&&userList.size()>0){
			userDtoList = new ArrayList<>();
			for(User user : userList){
				userDtoList.add(copyEntityToDto.copyUserEntityToDto(user));
			}
		}
		request.setAttribute("userList", userDtoList);
		return "_admin/user";
	}
	
	/**
	 * 根据试题Id查看所有试题
	 * @param request
	 * @return
	 */
	@RequestMapping("/getStuExamByExamId")
	public String getStuExamByExamId(HttpServletRequest request){
		String examId = request.getParameter("examId");
		request.setAttribute("subList", subjectService.getAllSubjects());
		request.setAttribute("stuExamList", stuExamService.getStuExamByExamId(Integer.parseInt(examId)));
		return "_admin/showScore";
	}
	
	/**
	 * 修改学生成绩
	 * @param request
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/updateExam")
	public String updateExam(HttpServletRequest request){
		String id = request.getParameter("id");
		String score = request.getParameter("score");
		String version = request.getParameter("version");
		StuExam stuExam = new StuExam();
		stuExam.setId(Integer.parseInt(id));
		stuExam.setScore(Integer.parseInt(score));
		stuExam.setVersion(Integer.parseInt(version));
		if(stuExamService.updateStuExamScore(stuExam)){
			return "0";
		}
		return "1";
	}
}
