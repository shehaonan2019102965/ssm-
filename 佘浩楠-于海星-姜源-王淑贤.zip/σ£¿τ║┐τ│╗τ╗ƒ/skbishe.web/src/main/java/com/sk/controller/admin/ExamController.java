package com.sk.controller.admin;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sk.commons.CopyEntityToDto;
import com.sk.commons.ExamConstant;
import com.sk.dto.ExamDto;
import com.sk.dto.QuestionsDto;
import com.sk.entity.Dict;
import com.sk.entity.Exam;
import com.sk.entity.ExamQuestion;
import com.sk.entity.Questions;
import com.sk.service.DictService;
import com.sk.service.ExamService;
import com.sk.service.QuestionService;

@RequestMapping("/admin")
@Controller
public class ExamController {

	@Autowired
	private ExamService examService;
	@Autowired
	private DictService dictService;
	@Autowired
	private QuestionService questionService;
	@Autowired
	private CopyEntityToDto copyEntityToDto;
	
	@ResponseBody
	@RequestMapping("/updateExamById")
	public String updateExamQues(Integer id,HttpServletRequest request){
		String[] ids = (String[])request.getParameterValues("qestionsIds");
		String version = request.getParameter("version");
		Integer[] qIds = new Integer[ids.length]; 
		for(int i = 0;i<ids.length;i++){
			qIds[i] = Integer.parseInt(ids[i]);
		}
		if(examService.editExam(qIds, id, Integer.parseInt(version))){
			return "0";
		}else{
			return "1";
		}
	}
	
	/**
	 * 获取试题的详细内容及所有本学科题库
	 * @param request
	 * @return
	 */
	@RequestMapping("/getExamByIdAndSid")
	public String getExamByIdAndSid(HttpServletRequest request){
		String examId = request.getParameter("id");
		String sid = request.getParameter("sid");
		List<Questions> questionList = questionService.getQuestionsBySid(Integer.parseInt(sid));
		ExamDto examDto =copyEntityToDto.copyExamEntityToDto(examService.getExamById(Integer.parseInt(examId)));
		request.setAttribute("questionDtoList", formatQuestionList(questionList,examDto.getQuestionsList()));
		request.setAttribute("examDto", examDto);
		return "_admin/examEdit";
	}
	
	/**
	 * 删除试卷
	 * @param request
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/delExam")
	public String delExamById(HttpServletRequest request){
		return "0";
	}
	
	/**
	 * 修改试卷状态
	 * @param request
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/editExamStatus")
	public String editExamStatus(HttpServletRequest request){
		String id = request.getParameter("id");
		String version = request.getParameter("version");
		String op = request.getParameter("op");
		if(id==null || version==null || op==null){
			return "1";
		}
		Exam exam = new Exam();
		exam.setId(Integer.parseInt(id));
		exam.setVersion(Integer.parseInt(version));
		if("open".equals(op)){
			exam.setExamstatusid(dictService.getDictByTypeAndCode(ExamConstant.EXAM_STATUS, ExamConstant.EXAM_STATUS_OPEN).getId());
		}else{
			exam.setExamstatusid(dictService.getDictByTypeAndCode(ExamConstant.EXAM_STATUS, ExamConstant.EXAM_STATUS_CLOSE).getId());
		}
		if(examService.updateExamStatus(exam)){
			return "0";
		}else{
			return "1";
		}
		
	}
	
	/**
	 * 添加试卷，试卷状态变为无试题
	 * @param request
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/doAddExam")
	public String addExam(HttpServletRequest request){
		String name = request.getParameter("name");
		if(examService.getExamByName(name)==null){
			String sid = request.getParameter("sid");
			String time = request.getParameter("time");
			Exam exam = new Exam();
			exam.setContent(name);
			exam.setSubjectid(Integer.parseInt(sid));
			exam.setExamstatusid(dictService.getDictByTypeAndCode(ExamConstant.EXAM_STATUS, ExamConstant.EXAM_STATUS_NOQUESTION).getId());
			exam.setExamtime(Integer.parseInt(time));
			exam.setVersion(0);
			if(examService.insertExam(exam)){
				return "0";
			}else{
				return "1";
			}
		}else{
			return "2";
		}
	}
	
	/**
	 * 处理试卷试题相关
	 * @param all
	 * @param select
	 * @return
	 */
	private List<QuestionsDto> formatQuestionList(List<Questions> all,List<ExamQuestion> select){
		List<QuestionsDto> dList = null;
		List<Dict> dictList = dictService.getDictByType(ExamConstant.QUES_TYPE);
		HashMap<Integer, String> dictMap = new HashMap<>();
		for(Dict d: dictList){
			dictMap.put(d.getId(), d.getContent());
		}
		if(all!=null){
			dList = new ArrayList<>();
			if(select==null || select.size()==0){//没有试题
				for(Questions q:all){
					QuestionsDto dto = new QuestionsDto();
					dto.setId(q.getId());
					dto.setContent(q.getContent());
					dto.setQtypeid(q.getQtypeid());
					dto.setType(dictMap.get(q.getQtypeid()));
					dto.setSubjectid(q.getSubjectid());
					dto.setXuanze(0);
					dto.setVersion(q.getVersion());
					dList.add(dto);
				}
			}else{
				HashMap<Integer, ExamQuestion> examQues = new HashMap<>();
				for(ExamQuestion eq : select){
					examQues.put(eq.getQuestid(), eq);
				}
				for(Questions q:all){
					QuestionsDto dto = new QuestionsDto();
					dto.setId(q.getId());
					dto.setContent(q.getContent());
					dto.setQtypeid(q.getQtypeid());
					dto.setType(dictMap.get(q.getQtypeid()));
					dto.setSubjectid(q.getSubjectid());
					dto.setVersion(q.getVersion());
					dto.setXuanze(examQues.get(q.getId())!=null?1:0);
					dList.add(dto);
				}
			}
		}
		return dList;
	}
	
}
