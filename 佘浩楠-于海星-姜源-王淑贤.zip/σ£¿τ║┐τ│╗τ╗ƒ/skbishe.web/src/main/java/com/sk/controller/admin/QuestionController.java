package com.sk.controller.admin;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sk.commons.CopyEntityToDto;
import com.sk.commons.ExamConstant;
import com.sk.dto.QuestionsDto;
import com.sk.dto.SelectedDto;
import com.sk.service.DictService;
import com.sk.service.QuestionService;
import com.sk.service.SubjectService;

@RequestMapping("/admin")
@Controller
public class QuestionController {

	@Autowired
	private QuestionService questionService;
	@Autowired
	private DictService dictService;
	@Autowired
	private CopyEntityToDto copyEntityToDto;
	@Autowired
	private SubjectService subjectService;
	
	/**
	 * 通过Id修改试题相关
	 * @param httpServletRequest
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/upQuestionById")
	public String updateQuestion(HttpServletRequest request){
		String content = request.getParameter("content");
		String[] id = request.getParameter("id").toString().split(";");
		QuestionsDto dto = new QuestionsDto();
		if(questionService.getQuestionByContentAndId(content,Integer.parseInt(id[0]))!=null){
			return "2";
		}else{
			String qtypeid = request.getParameter("qtypeid");
			String result = request.getParameter("result");
			String sid = request.getParameter("sid");
			dto.setContent(content);
			dto.setQtypeid(Integer.parseInt(qtypeid));
			dto.setResult(Integer.parseInt(result));
			dto.setSubjectid(Integer.parseInt(sid));
			dto.setId(Integer.parseInt(id[0]));
			dto.setVersion(Integer.parseInt(id[1]));
			List<SelectedDto> sList = null;
			if(dictService.getDictByTypeAndCode(ExamConstant.QUES_TYPE, ExamConstant.QUES_SELECT).getId().equals(Integer.parseInt(qtypeid))){
				sList = new ArrayList<>();
				String[] Aid = request.getParameter("Aid").toString().split(";");
				String[] Bid = request.getParameter("Bid").toString().split(";");
				String[] Cid = request.getParameter("Cid").toString().split(";");
				String[] Did = request.getParameter("Did").toString().split(";");
				SelectedDto A = 
						new SelectedDto(Integer.parseInt(Aid[0]),Integer.parseInt(id[0]),dictService.getDictByTypeAndCode(ExamConstant.QUES_SELECT_TYPE, ExamConstant.QUES_A).getId(), request.getParameter("A"), Integer.parseInt(Aid[1]));
				SelectedDto B =  
						new SelectedDto(Integer.parseInt(Bid[0]),Integer.parseInt(id[0]),dictService.getDictByTypeAndCode(ExamConstant.QUES_SELECT_TYPE, ExamConstant.QUES_B).getId(), request.getParameter("B"), Integer.parseInt(Bid[1]));
				SelectedDto C =  
						new SelectedDto(Integer.parseInt(Cid[0]),Integer.parseInt(id[0]),dictService.getDictByTypeAndCode(ExamConstant.QUES_SELECT_TYPE, ExamConstant.QUES_C).getId(), request.getParameter("C"), Integer.parseInt(Cid[1]));
				SelectedDto D =  
						new SelectedDto(Integer.parseInt(Did[0]),Integer.parseInt(id[0]),dictService.getDictByTypeAndCode(ExamConstant.QUES_SELECT_TYPE, ExamConstant.QUES_D).getId(), request.getParameter("D"), Integer.parseInt(Did[1]));
				sList.add(A);
				sList.add(B);
				sList.add(C);
				sList.add(D);
			}
			dto.setSelecteds(sList);
			if(questionService.updateQuestionById(dto)){
				return "0";
			}else{
				return "1";
			}
		}
	}
	
	/**
	 * 查看具体试题
	 * @param request
	 * @return
	 */
	@RequestMapping("/getQuestionById")
	public String getQuestionById(HttpServletRequest request){
		String id = request.getParameter("id");
		request.setAttribute("subList", subjectService.getAllSubjects());
		request.setAttribute("qDto",copyEntityToDto.copyQuesEntityToDto(questionService.getQuestionById(Integer.parseInt(id))));
		return "_admin/questionUpdate";
	}
	
	/**
	 * 删除试题并删除其关联选项
	 * @param request
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/deleteQuestion")
	public String delQuestion(HttpServletRequest request){
		String qid = request.getParameter("qid");
		String tid = request.getParameter("tid");
		if(qid==null || "".equals(qid)){
			return "1";
		}else{
			if(questionService.delQuestionById(Integer.parseInt(qid),Integer.parseInt(tid))){
				return "0";
			}else{
				return "1";
			}
		}
		
	}
	
	/**
	 * 添加试题
	 * @param request
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/doAddQuestion")
	public String addQuestion(HttpServletRequest request){
		String content = request.getParameter("content");
		QuestionsDto dto = new QuestionsDto();
		if(questionService.getQuestionByContent(content)!=null){
			return "2";
		}else{
			String qtypeid = request.getParameter("qtypeid");
			String result = request.getParameter("result");
			String sid = request.getParameter("sid");
			dto.setContent(content);
			dto.setQtypeid(Integer.parseInt(qtypeid));
			dto.setResult(Integer.parseInt(result));
			dto.setSubjectid(Integer.parseInt(sid));
			dto.setVersion(0);
			List<SelectedDto> sList = null;
			if(dictService.getDictByTypeAndCode(ExamConstant.QUES_TYPE, ExamConstant.QUES_SELECT).getId().equals(Integer.parseInt(qtypeid))){
				sList = new ArrayList<>();
				SelectedDto A = 
						new SelectedDto(dictService.getDictByTypeAndCode(ExamConstant.QUES_SELECT_TYPE, ExamConstant.QUES_A).getId(), request.getParameter("A"), 0);
				SelectedDto B =  
						new SelectedDto(dictService.getDictByTypeAndCode(ExamConstant.QUES_SELECT_TYPE, ExamConstant.QUES_B).getId(), request.getParameter("B"), 0);
				SelectedDto C =  
						new SelectedDto(dictService.getDictByTypeAndCode(ExamConstant.QUES_SELECT_TYPE, ExamConstant.QUES_C).getId(), request.getParameter("C"), 0);
				SelectedDto D =  
						new SelectedDto(dictService.getDictByTypeAndCode(ExamConstant.QUES_SELECT_TYPE, ExamConstant.QUES_D).getId(), request.getParameter("D"), 0);
				sList.add(A);
				sList.add(B);
				sList.add(C);
				sList.add(D);
			}
			dto.setSelecteds(sList);
			if(questionService.addQuestion(dto)){
				return "0";
			}else{
				return "1";
			}
		}
	}
	
	
}
