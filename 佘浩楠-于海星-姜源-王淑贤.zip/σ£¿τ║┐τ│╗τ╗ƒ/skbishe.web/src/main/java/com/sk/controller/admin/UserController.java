package com.sk.controller.admin;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sk.commons.util.MD5EncodingUtil;
import com.sk.entity.User;
import com.sk.service.UserService;

@RequestMapping("/admin")
@Controller
public class UserController {

	@Autowired
	private UserService userService;
	
	/**
	 * 删除用户
	 * @param request
	 * @return
	 */
	@RequestMapping(value="/deleteUser",method=RequestMethod.POST)
	@ResponseBody
	public String delUserByUserId(HttpServletRequest request){
		String userId = request.getParameter("userId").trim();
		if(userId != null && userService.delUserById(Integer.parseInt(userId))){
			return "0";//删除成功
		}else{
			return "1";//删除失败
		}
		
	}
	
	/**
	 * 通过Id修改用户
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/updateUserById")
	@ResponseBody
	public String updateUserById(HttpServletRequest request){
		String userId = request.getParameter("userId").trim();
		String status = request.getParameter("status");
		User updateUser = userService.getUserById(Integer.parseInt(userId)); 
		updateUser.setStatusid(Integer.parseInt(status));
		if(userService.updateUser(updateUser)){
			return "0";
		}else{
			return "1";
		}
	}
	
	/**
	 * 重置密码
	 * @param request
	 * @return
	 */
	@RequestMapping("/updatePwd")
	@ResponseBody
	public String updateUserPassword(HttpServletRequest request){
		String userId = request.getParameter("userId").trim();
		User updatePassword = userService.getUserById(Integer.parseInt(userId));
		updatePassword.setPassword(MD5EncodingUtil.getMD5(updatePassword.getUsername()));//默认把用户名作为密码
		if(userService.updateUser(updatePassword)){
			return "0";
		}else{
			return "1";
		}
	}
	
	/**
	 * 添加用户
	 * @param request
	 * @return
	 */
	@RequestMapping("doAddUser")
	@ResponseBody
	public String doAddUser(HttpServletRequest request){
		String username = request.getParameter("userName");
		if(username.length()<3){
			return "1";
		}
		if(userService.getUserByName(username)!=null){
			return "2";
		}
		String pwd = request.getParameter("pwd");
		String usertypeid = request.getParameter("type");
		User user = new User();
		user.setPassword(pwd);
		user.setUsername(username);
		user.setTypeid(Integer.parseInt(usertypeid));
		user.setStatusid(1);//
		user.setVersion(0);
		if(userService.addUser(user)){
			return "0";
		}else{
			return "1";
		}
		
	}
}
