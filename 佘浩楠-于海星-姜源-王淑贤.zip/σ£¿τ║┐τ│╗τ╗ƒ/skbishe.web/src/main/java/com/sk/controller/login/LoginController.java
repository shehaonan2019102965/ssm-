package com.sk.controller.login;

import java.io.UnsupportedEncodingException;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sk.commons.CopyEntityToDto;
import com.sk.commons.ExamConstant;
import com.sk.commons.util.MD5EncodingUtil;
import com.sk.dto.UserDto;
import com.sk.entity.Dict;
import com.sk.entity.Loginmsg;
import com.sk.entity.User;
import com.sk.service.DictService;
import com.sk.service.UserService;


@Controller
@RequestMapping("/login")
public class LoginController {

	@Autowired
	private UserService userService;
	@Autowired
	private DictService dictService;
	@Autowired
	private CopyEntityToDto copyEntityToDto;
	
	
	
	@RequestMapping("/index")
	public String login(HttpServletRequest request, HttpSession session){
		session.setAttribute("userType", dictService.getDictByType(ExamConstant.USERTYPE_TYPE));
		session.setAttribute("userStatus", dictService.getDictByType(ExamConstant.USER_STATUS_TYPE));
		session.setAttribute("examStatus",dictService.getDictByType(ExamConstant.EXAM_STATUS));
		session.setAttribute("quesType", dictService.getDictByType(ExamConstant.QUES_TYPE));
		session.setAttribute("quesSelect", dictService.getDictByType(ExamConstant.QUES_SELECT_TYPE));
		session.setAttribute("questJudge", dictService.getDictByType(ExamConstant.QUES_JUDGE_TYPE));
		return "login";
	}
	
	@RequestMapping("/exitExamSystem")
	public String exitExamSys(HttpServletRequest request){
		request.getSession().invalidate();
		return "index";
	}
	
	@ResponseBody
	@RequestMapping("/login")
	public String dologin(HttpServletRequest request, UserDto dto) throws UnsupportedEncodingException{
//		String code = req.getSession().getAttribute("code").toString();
		String result = "0";
		Dict loginMsgDict_Success = dictService.getDictByTypeAndCode(ExamConstant.LOGIN_RES_TYPE, ExamConstant.LOGIN_RES_SUCCESS);
		Dict loginMsgDict_Fail = dictService.getDictByTypeAndCode(ExamConstant.LOGIN_RES_TYPE, ExamConstant.LOGIN_RES_FAIL);
		HttpSession session = request.getSession();
		request.setCharacterEncoding("UTF-8");
		String code = request.getParameter("code");
		String ipAddress = getIpAddress(request);//IP地址
		Loginmsg msg = new Loginmsg();
		msg.setLogintime(new Date());
		msg.setUserip(ipAddress);
		msg.setUsername(dto.getUsername());
		if(code.equals(ExamConstant.CODE)){
			dto.setPassword(MD5EncodingUtil.getMD5(dto.getPassword()));
			User user = userService.login(dto);
			if(user != null){
				if(user.getStatusid().equals(dictService.getDictByTypeAndCode(ExamConstant.USER_STATUS_TYPE, ExamConstant.USER_STATUS_AVAILABLE).getId())){
					msg.setLoginstatusid(loginMsgDict_Success.getId());
					if(user.getTypeid().equals(dictService.getDictByTypeAndCode(ExamConstant.USERTYPE_TYPE, ExamConstant.USERTYPE_ADMIN).getId())){
						session.setAttribute("Admin", copyEntityToDto.copyUserEntityToDto(user));
						result =  "2";//管理员登陆
					}else if(user.getTypeid().equals(dictService.getDictByTypeAndCode(ExamConstant.USERTYPE_TYPE, ExamConstant.USERTYPE_TEACH).getId())){
						session.setAttribute("Teacher", copyEntityToDto.copyUserEntityToDto(user));
						result = "3";//教师登陆
					}else{
						session.setAttribute("Student", copyEntityToDto.copyUserEntityToDto(user));
						result = "4";//学生登陆
					}
				}else{
					result = "5";//账号状态不可用，请联系管理员
					msg.setLoginstatusid(loginMsgDict_Fail.getId());
				}
			}else{
				result = "1";//账号或密码错误!
				msg.setLoginstatusid(loginMsgDict_Fail.getId());
			}
		}else{
			result = "0";//验证码错误
			msg.setLoginstatusid(loginMsgDict_Fail.getId());
		}
		msg.setVersion(0);
		userService.addLoginMsg(msg);
		return result;
	}
	
	/**
	 * 获取用户Ip
	 * @param request
	 * @return
	 */
    private static String getIpAddress(HttpServletRequest request) {  
        String ip = request.getHeader("x-forwarded-for");  
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {  
            ip = request.getHeader("Proxy-Client-IP");  
        }  
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {  
            ip = request.getHeader("WL-Proxy-Client-IP");  
        }  
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {  
            ip = request.getHeader("HTTP_CLIENT_IP");  
        }  
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {  
            ip = request.getHeader("HTTP_X_FORWARDED_FOR");  
        }  
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {  
            ip = request.getRemoteAddr();  
        }  
        return ip;  
    }
	
}
