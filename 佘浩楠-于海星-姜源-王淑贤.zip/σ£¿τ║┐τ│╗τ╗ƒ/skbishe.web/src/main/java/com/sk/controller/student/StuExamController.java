package com.sk.controller.student;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sk.commons.CopyEntityToDto;
import com.sk.dto.ExamDto;
import com.sk.dto.QuestionsDto;
import com.sk.dto.UserDto;
import com.sk.entity.ExamQuestion;
import com.sk.entity.StuExam;
import com.sk.service.ExamService;
import com.sk.service.QuestionService;
import com.sk.service.StuExamService;

@RequestMapping("/student")
@Controller
public class StuExamController {

	@Autowired
	private StuExamService stuExamService;
	@Autowired
	private ExamService examService;
	@Autowired
	private CopyEntityToDto copyEntityToDto;
	@Autowired
	private QuestionService questionService;

	
	@RequestMapping("/getStuExamByExamId")
	public String showStuExamByExamId(HttpServletRequest request){
		String examId = request.getParameter("examId");
		UserDto dto = (UserDto)request.getSession().getAttribute("Student");
		StuExam stuExam = stuExamService.getStuExamBySidAndExamId(Integer.parseInt(dto.getUsername()), Integer.parseInt(examId));
		request.setAttribute("StuExamDto", copyEntityToDto.copyStuExamToDto(stuExam));
		return "_student/showExam";
	}
	/**
	 * 学生答题
	 * @param request
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/upStuExam")
	public String upStuExam(HttpServletRequest request){
		UserDto user = (UserDto)request.getSession().getAttribute("Student");
		String examId = request.getParameter("examId");
		String stuExamId = request.getParameter("stuExamId");
		String version = request.getParameter("version");
		String[] qIdAndSid = (String[])request.getParameterValues("qIdAndSid");
		StuExam stuExam = new StuExam();
		stuExam.setId(Integer.parseInt(stuExamId));
		stuExam.setStuid(Integer.parseInt(user.getUsername()));
		stuExam.setEndtime(new Date());
		stuExam.setExamid(Integer.parseInt(examId));
		stuExam.setVersion(Integer.parseInt(version));
		if(stuExamService.addStuExam(stuExam, qIdAndSid)){
			return "0";
		}
		return "1";
	}
	
	/**
	 * 学生参加考试
	 * @param request
	 * @return
	 */
	@RequestMapping("/addStuExam")
	public String addStuExam(HttpServletRequest request){
		String examId = request.getParameter("examId");
		UserDto user = (UserDto)request.getSession().getAttribute("Student");
		StuExam stuExam = new StuExam();
		stuExam.setStuid(Integer.parseInt(user.getUsername()));
		stuExam.setExamid(Integer.parseInt(examId));
		stuExam.setStarttime(new Date());
		stuExam.setVersion(0);
		int stuExamId = stuExamService.addStuExam(stuExam);
		if(stuExamId==-1){
			return "_student/exam";
		}else{
			ExamDto dto =  copyEntityToDto.copyExamEntityToDto(examService.getExamById(Integer.parseInt(examId)));
			List<QuestionsDto> quesDtoList = new ArrayList<>();
			for(ExamQuestion eq : dto.getQuestionsList()){
				quesDtoList.add(copyEntityToDto.copyQuesEntityToDto(questionService.getQuestionById(eq.getQuestid())));
			}
			dto.setQuesDtoList(quesDtoList);
			request.setAttribute("examDto",dto);//获取试题及其问题
			request.setAttribute("stuExam", stuExamService.getStuExamById(stuExamId));//参加考试纪录
			return "_student/inExam";
		}
	}
	
}
