package com.sk.controller.student;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sk.commons.ExamConstant;
import com.sk.dto.ExamDto;
import com.sk.dto.StuExamDto;
import com.sk.dto.UserDto;
import com.sk.entity.Exam;
import com.sk.entity.StuExam;
import com.sk.service.DictService;
import com.sk.service.ExamService;
import com.sk.service.StuExamService;
import com.sk.service.SubjectService;


@Controller
@RequestMapping("/student")
public class StudentController {

	@Autowired
	private ExamService examService;
	@Autowired
	private DictService dictService;
	@Autowired
	private StuExamService stuExamService;
	@Autowired
	private SubjectService subjectService;
	
	
	/**
	 * 学生管理首页
	 * @return
	 */
	@RequestMapping("/index")
	public String studentIndex(){
		return "_student/index";
	}
	
	/**
	 * 学生试卷管理页面
	 * @param request
	 * @return
	 */
	@RequestMapping("/exam")
	public String examIndex(HttpServletRequest request){
		List<Exam> openExamList = examService.getExamsByStatus(dictService.getDictByTypeAndCode(ExamConstant.EXAM_STATUS, ExamConstant.EXAM_STATUS_OPEN).getId());
		UserDto userDto = (UserDto)request.getSession().getAttribute("Student");
		List<StuExam> stuExamList = stuExamService.getStuExamsByStuId(Integer.parseInt(userDto.getUsername()));
//		request.setAttribute("stuExamList", stuExamList);
		request.setAttribute("subList", subjectService.getAllSubjects());
		request.setAttribute("openExamList", formatExam(openExamList,stuExamList));
		return "_student/exam";
	}
	
	/**
	 * 查看本人成绩
	 * @param request
	 * @return
	 */
	@RequestMapping("/score")
	public String scoreIndex(HttpServletRequest request){
		UserDto user = (UserDto)request.getSession().getAttribute("Student");
		List<StuExamDto> dtoList = new ArrayList<>();
		List<StuExam> list = stuExamService.getStuExamsByStuId(Integer.parseInt(user.getUsername()));
		if(list!=null&&list.size()>0){
			for(StuExam se:list){
				StuExamDto sed = new StuExamDto();
				sed.setId(se.getId());
				Exam exam = examService.getExamById(se.getExamid());
				sed.setContent(exam.getContent());
				sed.setSubject(exam.getSubjectid());
				sed.setScore(se.getScore());
				dtoList.add(sed);
			}
		}
		request.setAttribute("subList", subjectService.getAllSubjects());
		request.setAttribute("StuExamList",dtoList);
		
		return "_student/score";
	}
	
	
	/**
	 * 格式化所有试卷：kaoshi: 1 考过；0 未参加
	 * 将满足条件的试题进行格式化处理，以满足展示需求
	 * @param all
	 * @param cy
	 * @return
	 */
	private List<ExamDto> formatExam(List<Exam> all,List<StuExam> cy){
		List<ExamDto> dList = null;
		if(all != null && all.size()>0){
			dList = new ArrayList<>();
			if(cy==null || cy.size()==0){
				for(Exam e:all){
					ExamDto dto = new ExamDto();
					dto.setId(e.getId());
					dto.setExamtime(e.getExamstatusid());
					dto.setExamtime(e.getExamtime());
					dto.setKaoshi(0);
					dto.setVersion(e.getVersion());
					dto.setSubjectid(e.getSubjectid());
					dto.setContent(e.getContent());
					dList.add(dto);
				}
			}else{
				HashMap<Integer, StuExam> stuExamMap = new HashMap<>();
				for(StuExam se : cy){
					stuExamMap.put(se.getExamid(), se);
				}
				for(Exam e:all){
					ExamDto dto = new ExamDto();
					dto.setId(e.getId());
					dto.setExamtime(e.getExamstatusid());
					dto.setExamtime(e.getExamtime());
					dto.setKaoshi((stuExamMap.get(e.getId())!=null)?1:0);
					dto.setVersion(e.getVersion());
					dto.setSubjectid(e.getSubjectid());
					dto.setContent(e.getContent());
					dList.add(dto);
				}
			}
		}
		return dList;
	}
	
	
}
