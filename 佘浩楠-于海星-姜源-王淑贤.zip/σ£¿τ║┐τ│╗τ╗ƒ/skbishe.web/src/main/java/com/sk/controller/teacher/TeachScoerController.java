package com.sk.controller.teacher;



import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sk.service.StuExamService;
import com.sk.service.SubjectService;


@Controller
@RequestMapping("/teacher")
public class TeachScoerController {
	
	@Autowired
	private StuExamService stuExamService;
	@Autowired
	private SubjectService subjectService;
	
	/**
	 * 根据试题Id查看所有试题
	 * @param request
	 * @return
	 */
	@RequestMapping("/getStuExamByExamId")
	public String getStuExamByExamId(HttpServletRequest request){
		String examId = request.getParameter("examId");
		request.setAttribute("subList", subjectService.getAllSubjects());
		request.setAttribute("stuExamList", stuExamService.getStuExamByExamId(Integer.parseInt(examId)));
		return "_teacher/showScore";
	}
	
	
	
}
