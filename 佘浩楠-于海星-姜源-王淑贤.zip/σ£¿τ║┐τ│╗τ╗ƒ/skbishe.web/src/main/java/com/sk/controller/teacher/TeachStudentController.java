package com.sk.controller.teacher;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sk.entity.Student;
import com.sk.service.StudentService;


@Controller
@RequestMapping("/teacher")
public class TeachStudentController {

	@Autowired
	private StudentService studentService;
	
	/**
	 * 删除学生
	 * @param request
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/deleteStu")
	public String delStudent(HttpServletRequest request){
		String stuno = request.getParameter("stuno");
		if(studentService.delStu(stuno)){
			return "0";
		}
		return "1";
	}
	
	/**
	 * 添加学生并且添加用户
	 * @param request
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/doAddStu")
	public String addStudent(HttpServletRequest request){
		String no = request.getParameter("no");
		String name = request.getParameter("name");
		if(studentService.getStudentByNo(no)!=null){
			return "2";
		}
		Student stu = new Student();
		stu.setStudentno(no);
		stu.setStudentname(name);
		stu.setVersion(0);
		if(studentService.addStu(stu)){
			return "0";
		}
		return "1";
	}
	
}
