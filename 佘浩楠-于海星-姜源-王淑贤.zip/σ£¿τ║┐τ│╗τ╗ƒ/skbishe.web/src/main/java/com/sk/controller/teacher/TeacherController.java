package com.sk.controller.teacher;


import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sk.commons.CopyEntityToDto;
import com.sk.dto.QuestionsDto;
import com.sk.entity.Exam;
import com.sk.entity.Questions;
import com.sk.entity.Subject;
import com.sk.service.ExamService;
import com.sk.service.QuestionService;
import com.sk.service.ScoreService;
import com.sk.service.StudentService;
import com.sk.service.SubjectService;


@RequestMapping("/teacher")
@Controller
public class TeacherController {

	@Autowired
	private StudentService studentService;
	@Autowired 
	private ScoreService scoreService;
	@Autowired
	private SubjectService subjectService;
	@Autowired
	private ExamService examService;
	@Autowired
	private QuestionService questionService;
	@Autowired 
	private CopyEntityToDto copyEntityToDto;
	
	/**
	 * 教师管理界面
	 * @return
	 */
	@RequestMapping("/index")
	public String teacherIndex(){
		return "_teacher/index";
	}
	
	/**
	 * 学生成绩管理界面  
	 * @param request
	 * @return
	 */
	@RequestMapping("/score")
	public String scoreIndex(HttpServletRequest request){
		request.setAttribute("subList", subjectService.getAllSubjects());
		request.setAttribute("scoreList", scoreService.getScoreForTeach());
		return "_teacher/score";
	}
	
	/**
	 * 学生管理界面
	 * @param request
	 * @return
	 */
	@RequestMapping("/student")
	public String studentIndex(HttpServletRequest request ){
		request.setAttribute("StudentList", studentService.getAllStudents());
		return "_teacher/student";
	}
	
	/**
	 * 题库管理
	 * @return
	 */
	@RequestMapping("/question")
	public String questionIndex(HttpServletRequest request){
		List<QuestionsDto> questDtoList = null;
		List<Questions> questList = questionService.getAllQuestions();
		if(questList != null&&questList.size()>0){
			questDtoList = new ArrayList<>();
			for(Questions q:questList){
				questDtoList.add(copyEntityToDto.copyQuesEntityToDto(q));
			}
		}
		request.setAttribute("subList", subjectService.getAllSubjects());
		request.setAttribute("questionList", questDtoList);
		return "_teacher/question";
	}
	
	/**
	 * 科目管理界面
	 * @return
	 */
	@RequestMapping("/subject")
	public String subjectIndex(HttpServletRequest request){
		List<Subject> subjectList = subjectService.getAllSubjects();
		request.setAttribute("subjectList", subjectList);
		return "_teacher/subject";
	}
	
	/**
	 * 试题管理首页
	 * @return
	 */
	@RequestMapping("/exam")
	public String examIndex(HttpServletRequest request){
		List<Exam> examList = examService.getAllExams();
		List<Subject> subList = subjectService.getAllSubjects();
		request.setAttribute("examList", examList);
		request.setAttribute("subList", subList);
		return "_teacher/exam";
	}
	
}
