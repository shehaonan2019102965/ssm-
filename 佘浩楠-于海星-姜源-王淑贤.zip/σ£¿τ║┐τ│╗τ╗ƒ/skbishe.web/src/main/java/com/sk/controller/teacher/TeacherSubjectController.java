package com.sk.controller.teacher;

import java.io.UnsupportedEncodingException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sk.entity.Subject;
import com.sk.service.SubjectService;

@RequestMapping("/teacher")
@Controller
public class TeacherSubjectController {
	
	@Autowired
	private SubjectService subjectService;
	
	
	/**
	 * 添加科目信息
	 * @return
	 * @throws UnsupportedEncodingException 
	 */
	@ResponseBody
	@RequestMapping("/doAddSubject")
	public String addSubject(HttpServletRequest request) throws UnsupportedEncodingException{
		request.setCharacterEncoding("UTF-8");
		String subjectName = request.getParameter("subjectName");
		String subjectContent = request.getParameter("subjectContent");
		if(subjectService.getSubjectByName(subjectName)!=null){
			return "2";
		}
		if(subjectName == null || "".equals(subjectName)){
			return "1";
		}else{
			Subject sub = new Subject();
			sub.setContent(subjectContent);
			sub.setSubjectname(subjectName);
			sub.setVersion(0);
			if(subjectService.addSubject(sub)){
				return "0";
			}else{
				return "1";
			}
		}
	}
	
	/**
	 * 修改科目相关信息
	 * @param request
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	@ResponseBody
	@RequestMapping("/updateSubjectById")
	public String updateSubjectById(HttpServletRequest request) throws UnsupportedEncodingException{
		request.setCharacterEncoding("UTF-8");
		String id = request.getParameter("id");
		String content = request.getParameter("content");
		String name = request.getParameter("name");
		if(id!=null){
			Subject sub = subjectService.getSubjectById(Integer.parseInt(id));
			sub.setSubjectname(name!=null?name:sub.getSubjectname());
			sub.setContent(content!=null?content:sub.getContent());
			if(subjectService.updateSubject(sub)){
				return "0";
			}else{
				return "1";
			}
			
		}else{
			return "1";
		}
	}
	
	/**
	 * 删除科目
	 * @param request
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/deleteSubject")
	public String deleteSubjectById(HttpServletRequest request){
		String id = request.getParameter("id");
		if(id!=null){
			if(subjectService.delSubjectById(Integer.parseInt(id))){
				return "0";
			}else{
				return "1";
			}
		}else{
			return "1";
		}
	}
	
	
	
}
