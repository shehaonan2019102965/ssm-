package com.sk.interceptor;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.sk.commons.ExamConstant;
import com.sk.dao.DictMapper;
import com.sk.dto.UserDto;

public class TeacherInterceptor  implements HandlerInterceptor{

	@Resource
	private DictMapper dictMapper;
	
	@Override
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler) throws Exception {
		HttpSession session = request.getSession();
		UserDto dto = (UserDto)session.getAttribute("Teacher");
		if(dto != null){
			if(dto.getTypeid()==dictMapper.selectDictByCodeAndType(ExamConstant.USERTYPE_TEACH, ExamConstant.USERTYPE_TYPE).getId()){
				return true;
			}else{
				response.sendRedirect("/skbishe.web/login/index");
				return false;
			}
		}else{
			response.sendRedirect("/skbishe.web/login/index");
			return false;
		}
	}

	@Override
	public void postHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void afterCompletion(HttpServletRequest request,
			HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		// TODO Auto-generated method stub
		
	}

}
